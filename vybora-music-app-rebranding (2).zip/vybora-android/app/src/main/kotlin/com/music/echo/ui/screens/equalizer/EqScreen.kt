package echo.music.iad1tya.ui.screens.equalizer

import android.annotation.SuppressLint
import android.content.Intent
import android.media.audiofx.AudioEffect
import android.media.session.PlaybackState
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import echo.music.iad1tya.LocalPlayerConnection
import echo.music.iad1tya.R
import echo.music.iad1tya.utils.launchSafely
import echo.music.dsp.core.models.SavedEQProfile
import timber.log.Timber

@SuppressLint("LocalContextGetResourceValueCall")
@Composable
fun EqScreen(
  navController: NavController? = null,
  viewModel: EQViewModel = hiltViewModel(),
  playbackState: PlaybackState? = null
) {
  val state by viewModel.state.collectAsStateWithLifecycle()
  val context = LocalContext.current
  val playerConnection = LocalPlayerConnection.current

  var showError by remember { mutableStateOf<String?>(null) }

  val activityResultLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {}

  val filePickerLauncher =
    rememberLauncherForActivityResult(contract = ActivityResultContracts.GetContent()) { uri ->
      if (uri != null) {
        try {
          val contentResolver = context.contentResolver

          var fileName = "custom_eq.txt"
          contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
              val displayNameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
              if (displayNameIndex >= 0) {
                val name = cursor.getString(displayNameIndex)
                if (!name.isNullOrBlank()) {
                  fileName = name
                }
              }
            }
          }

          val inputStream = contentResolver.openInputStream(uri)

          if (inputStream != null) {
            viewModel.importCustomProfile(
              fileName = fileName,
              inputStream = inputStream,
              onSuccess = { Timber.d("Custom EQ profile imported successfully: $fileName") },
              onError = { error ->
                Timber.d("Error: Unable to import Custom EQ profile: $fileName")
                showError = context.getString(R.string.import_error_title) + ": " + error.message
              }
            )
          } else {
            showError = context.getString(R.string.error_file_read)
          }
        } catch (e: Exception) {
          showError = context.getString(R.string.error_file_open, e.message)
        }
      }
    }

  EqScreenContent(
    profiles = state.profiles,
    activeProfileId = state.activeProfileId,
    onProfileSelected = { viewModel.selectProfile(it) },
    onImportCustomEQ = { filePickerLauncher.launchSafely("text/plain", context) },
    onOpenSystemEqualizer = {
      playerConnection?.let { connection ->
        val intent =
          Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL).apply {
            putExtra(AudioEffect.EXTRA_AUDIO_SESSION, connection.player.audioSessionId)
            putExtra(AudioEffect.EXTRA_PACKAGE_NAME, context.packageName)
            putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
          }
        if (intent.resolveActivity(context.packageManager) != null) {
          activityResultLauncher.launch(intent)
        }
      }
    },
    onNavigateToAxion = { navController?.navigate("settings/equalizer") },
    onDeleteProfile = { viewModel.deleteProfile(it) }
  )

  if (showError != null) {
    AlertDialog(
      onDismissRequest = { showError = null },
      title = { Text(stringResource(R.string.import_error_title)) },
      text = { Text(showError ?: "") },
      confirmButton = {
        TextButton(onClick = { showError = null }) { Text(stringResource(android.R.string.ok)) }
      }
    )
  }

  if (state.error != null) {
    AlertDialog(
      onDismissRequest = { viewModel.clearError() },
      title = { Text(stringResource(R.string.error_title)) },
      text = { Text(stringResource(R.string.error_eq_apply_failed, state.error ?: "")) },
      confirmButton = {
        TextButton(onClick = { viewModel.clearError() }) {
          Text(stringResource(android.R.string.ok))
        }
      }
    )
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EqScreenContent(
  profiles: List<SavedEQProfile>,
  activeProfileId: String?,
  onProfileSelected: (String?) -> Unit,
  onImportCustomEQ: () -> Unit,
  onOpenSystemEqualizer: () -> Unit,
  onNavigateToAxion: () -> Unit,
  onDeleteProfile: (String) -> Unit
) {
  androidx.compose.material3.Card(
    modifier = Modifier.fillMaxWidth().heightIn(max = 600.dp).padding(24.dp),
    shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
    colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = androidx.compose.material3.CardDefaults.cardElevation(defaultElevation = 8.dp)
  ) {
    Column {
      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text(
            text = stringResource(R.string.equalizer_header),
            style = MaterialTheme.typography.headlineSmall
          )
          Text(
            text =
              pluralStringResource(
                id = R.plurals.profiles_count,
                count = profiles.size,
                profiles.size
              ),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        Row {
          IconButton(onClick = onNavigateToAxion) {
            Icon(
              painter = painterResource(R.drawable.tune),
              contentDescription = stringResource(R.string.echo_equalizer)
            )
          }
          IconButton(onClick = onImportCustomEQ) {
            Icon(
              painter = painterResource(R.drawable.add),
              contentDescription = stringResource(R.string.import_profile)
            )
          }
          IconButton(onClick = onOpenSystemEqualizer) {
            Icon(
              painter = painterResource(R.drawable.equalizer),
              contentDescription = stringResource(R.string.system_equalizer)
            )
          }
        }
      }

      LazyColumn(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 16.dp)
      ) {
        item {
          androidx.compose.material3.Card(
            shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
            colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
            elevation = androidx.compose.material3.CardDefaults.cardElevation(defaultElevation = 0.dp),
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
          ) {
            NoEqualizationItem(
              isSelected = activeProfileId == null,
              onSelected = { onProfileSelected(null) }
            )
          }
        }

        val customProfiles = profiles.filter { it.isCustom }

        if (customProfiles.isNotEmpty()) {
          items(customProfiles) { profile ->
            androidx.compose.material3.Card(
              shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
              colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
              elevation = androidx.compose.material3.CardDefaults.cardElevation(defaultElevation = 0.dp),
              modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
            ) {
              EQProfileItem(
                profile = profile,
                isSelected = activeProfileId == profile.id,
                onSelected = { onProfileSelected(profile.id) },
                onDelete = { onDeleteProfile(profile.id) }
              )
            }
          }
        }

        if (customProfiles.isEmpty()) {
          item {
            Box(
              modifier = Modifier.fillMaxWidth().padding(32.dp),
              contentAlignment = Alignment.Center
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                  painter = painterResource(R.drawable.equalizer),
                  contentDescription = null,
                  modifier = Modifier.size(48.dp),
                  tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                  text = stringResource(R.string.no_profiles),
                  style = MaterialTheme.typography.titleMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(onClick = onImportCustomEQ) { Text(stringResource(R.string.import_profile)) }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(onClick = onOpenSystemEqualizer) {
                  Text(stringResource(R.string.system_equalizer))
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun NoEqualizationItem(isSelected: Boolean, onSelected: () -> Unit) {
  ListItem(colors = androidx.compose.material3.ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
    headlineContent = {
      Text(
        stringResource(R.string.eq_disabled),
        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
      )
    },
    leadingContent = { RadioButton(selected = isSelected, onClick = onSelected) },
    modifier = Modifier.clickable(onClick = onSelected)
  )
}

@Composable
private fun EQProfileItem(
  profile: SavedEQProfile,
  isSelected: Boolean,
  onSelected: () -> Unit,
  onDelete: () -> Unit
) {
  var showDeleteDialog by remember { mutableStateOf(false) }

  ListItem(colors = androidx.compose.material3.ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
    headlineContent = {
      Text(
        text = profile.deviceModel,
        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
      )
    },
    supportingContent = {
      Text(
        pluralStringResource(
          id = R.plurals.band_count,
          count = profile.bands.size,
          profile.bands.size
        )
      )
    },
    leadingContent = { RadioButton(selected = isSelected, onClick = onSelected) },
    trailingContent = {
      IconButton(onClick = { showDeleteDialog = true }) {
        Icon(
          painter = painterResource(R.drawable.delete),
          contentDescription = stringResource(R.string.delete_profile_desc),
          tint = MaterialTheme.colorScheme.error
        )
      }
    },
    modifier = Modifier.clickable(onClick = onSelected)
  )

  if (showDeleteDialog) {
    AlertDialog(
      onDismissRequest = { showDeleteDialog = false },
      title = { Text(stringResource(R.string.delete_profile_desc)) },
      text = { Text(stringResource(R.string.delete_profile_confirmation, profile.name)) },
      confirmButton = {
        TextButton(
          onClick = {
            onDelete()
            showDeleteDialog = false
          }
        ) {
          Text(stringResource(android.R.string.ok))
        }
      },
      dismissButton = {
        TextButton(onClick = { showDeleteDialog = false }) {
          Text(stringResource(android.R.string.cancel))
        }
      }
    )
  }
}
