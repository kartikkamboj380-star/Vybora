/** vivimusic Project (C) 2026 Licensed under GPL-3.0 | See git history for contributors */
package echo.music.iad1tya.ui.player

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.isSpecified
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.compose.AsyncImage
import echo.music.iad1tya.LocalListenTogetherManager
import echo.music.iad1tya.LocalPlayerConnection
import echo.music.iad1tya.R
import echo.music.iad1tya.constants.SwipeSensitivityKey
import echo.music.iad1tya.constants.SwipeThumbnailKey
import echo.music.iad1tya.extensions.togglePlayPause
import echo.music.iad1tya.utils.rememberPreference
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

/**
 * Compact now playing controls docked inside the floating tab bar, mirroring the iOS 26 Apple Music
 * accessory: a wide pill above the tabs when the bar is expanded, and a slim strip between the tab
 * pill and the search tab when inline.
 *
 * Swiping the artwork/title area horizontally changes the song, honoring the same swipe preferences
 * and thresholds as [MiniPlayer]. Tapping the row invokes [onClick] (which opens the full player).
 */
@Composable
fun FloatingMiniPlayer(
  isInline: Boolean,
  contentColor: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val playerConnection = LocalPlayerConnection.current ?: return
  val mediaMetadata by playerConnection.mediaMetadata.collectAsStateWithLifecycle()
  val isPlaying by playerConnection.isPlaying.collectAsStateWithLifecycle()

  val swipeSensitivity by rememberPreference(SwipeSensitivityKey, 0.73f)
  val swipeThumbnailPref by rememberPreference(SwipeThumbnailKey, true)
  val listenTogetherManager = LocalListenTogetherManager.current
  val isListenTogetherGuest = listenTogetherManager?.let { it.isInRoom && !it.isHost } ?: false
  val swipeEnabled = swipeThumbnailPref && !isListenTogetherGuest

  val layoutDirection = LocalLayoutDirection.current
  val coroutineScope = rememberCoroutineScope()

  val offsetXAnimatable = remember { Animatable(0f) }
  var dragStartTime by remember { mutableLongStateOf(0L) }
  var totalDragDistance by remember { mutableFloatStateOf(0f) }
  val animationSpec = remember {
    spring<Float>(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessLow)
  }
  val autoSwipeThreshold =
    remember(swipeSensitivity) {
      (600 / (1f + exp(-(-11.44748 * swipeSensitivity + 9.04945)))).roundToInt()
    }

  val artSize = if (isInline) 32.dp else 44.dp
  val artCornerRadius = if (isInline) 8.dp else 10.dp
  val controlSize = if (isInline) 32.dp else 40.dp

  val currentItem = playerConnection.player.currentMediaItem
  val resolvedTitle =
    mediaMetadata?.title?.takeIf { it.isNotBlank() }
      ?: currentItem?.mediaMetadata?.title?.toString()?.takeIf { it.isNotBlank() }
      ?: currentItem?.mediaMetadata?.displayTitle?.toString()?.takeIf { it.isNotBlank() }
      ?: ""

  val resolvedArtist =
    mediaMetadata?.artists?.joinToString { it.name }?.takeIf { it.isNotBlank() }
      ?: currentItem?.mediaMetadata?.artist?.toString()?.takeIf { it.isNotBlank() }
      ?: currentItem?.mediaMetadata?.albumArtist?.toString()?.takeIf { it.isNotBlank() }
      ?: ""

  val resolvedArtwork =
    mediaMetadata?.thumbnailUrl?.takeIf { it.isNotBlank() }
      ?: currentItem?.mediaMetadata?.artworkUri?.toString()
      ?: currentItem?.mediaMetadata?.extras?.getString("artwork_uri")

  val effectiveContentColor =
    if (contentColor.isSpecified && contentColor != Color.Transparent) {
      contentColor
    } else {
      if (MaterialTheme.colorScheme.surface.luminance() > 0.5f) Color.Black else Color.White
    }

  // iOS 26 style press response: the whole glass pill grows slightly while touched.
  val pressInteractionSource = remember { MutableInteractionSource() }
  val isPressed by pressInteractionSource.collectIsPressedAsState()
  val pressScale by
    animateFloatAsState(
      targetValue = if (isPressed) 1.04f else 1f,
      animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
      label = "accessoryPressScale",
    )

  // Same structure as MiniPlayer: the drag detector sits on the outermost
  // container so the whole accessory is swipeable, and the entire content row
  // slides with the drag.
  Box(
    contentAlignment = Alignment.CenterStart,
    modifier =
      Modifier.graphicsLayer {
          scaleX = pressScale
          scaleY = pressScale
        }
        .then(modifier)
        .clipToBounds()
        .then(
          if (swipeEnabled) {
            Modifier.pointerInput(Unit) {
              detectHorizontalDragGestures(
                onDragStart = {
                  dragStartTime = System.currentTimeMillis()
                  totalDragDistance = 0f
                },
                onDragCancel = {
                  coroutineScope.launch { offsetXAnimatable.animateTo(0f, animationSpec) }
                },
                onHorizontalDrag = { _, dragAmount ->
                  val adjustedDragAmount =
                    if (layoutDirection == LayoutDirection.Rtl) -dragAmount else dragAmount
                  val canSkipPrevious = playerConnection.player.previousMediaItemIndex != -1
                  val canSkipNext = playerConnection.player.nextMediaItemIndex != -1
                  val tryingToSwipeRight = adjustedDragAmount > 0
                  val tryingToSwipeLeft = adjustedDragAmount < 0
                  val allowLeft = tryingToSwipeLeft && canSkipNext
                  val allowRight = tryingToSwipeRight && canSkipPrevious

                  val canReturnToCenter =
                    (tryingToSwipeRight && !canSkipPrevious && offsetXAnimatable.value < 0) ||
                      (tryingToSwipeLeft && !canSkipNext && offsetXAnimatable.value > 0)

                  if (allowLeft || allowRight || canReturnToCenter) {
                    totalDragDistance += abs(adjustedDragAmount)
                    coroutineScope.launch {
                      offsetXAnimatable.snapTo(offsetXAnimatable.value + adjustedDragAmount)
                    }
                  }
                },
                onDragEnd = {
                  val dragDuration = System.currentTimeMillis() - dragStartTime
                  val velocity = if (dragDuration > 0) totalDragDistance / dragDuration else 0f
                  val currentOffset = offsetXAnimatable.value
                  val minDistanceThreshold = 50f
                  val velocityThreshold = (swipeSensitivity * -8.25f) + 8.5f
                  val canSkipPrevious = playerConnection.player.previousMediaItemIndex != -1
                  val canSkipNext = playerConnection.player.nextMediaItemIndex != -1

                  val shouldChangeSong =
                    (abs(currentOffset) > minDistanceThreshold && velocity > velocityThreshold) ||
                      (abs(currentOffset) > autoSwipeThreshold)

                  if (shouldChangeSong) {
                    if (currentOffset > 0 && canSkipPrevious) {
                      playerConnection.player.seekToPreviousMediaItem()
                    } else if (currentOffset <= 0 && canSkipNext) {
                      playerConnection.player.seekToNext()
                    }
                  }
                  coroutineScope.launch { offsetXAnimatable.animateTo(0f, animationSpec) }
                },
              )
            }
          } else {
            Modifier
          }
        ),
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier =
        Modifier.fillMaxWidth()
          .offset { IntOffset(offsetXAnimatable.value.roundToInt(), 0) }
          .clickable(
            interactionSource = pressInteractionSource,
            indication = null,
            onClick = onClick,
          )
          .padding(
            horizontal = if (isInline) 8.dp else 12.dp,
            vertical = if (isInline) 4.dp else 8.dp,
          ),
    ) {
      AsyncImage(
        model = resolvedArtwork,
        placeholder = painterResource(R.drawable.music_note),
        error = painterResource(R.drawable.music_note),
        fallback = painterResource(R.drawable.music_note),
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier =
          Modifier.size(artSize)
            .clip(RoundedCornerShape(artCornerRadius))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
      )

      Spacer(Modifier.width(if (isInline) 8.dp else 12.dp))

      if (isInline) {
        Text(
          text = resolvedTitle,
          style = MaterialTheme.typography.bodySmall,
          color = effectiveContentColor,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.weight(1f),
        )
      } else {
        Column(
          modifier = Modifier.weight(1f),
          verticalArrangement = Arrangement.Center,
        ) {
          Text(
            text = resolvedTitle,
            style = MaterialTheme.typography.bodyMedium,
            color = effectiveContentColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          if (resolvedArtist.isNotBlank()) {
            Text(
              text = resolvedArtist,
              style = MaterialTheme.typography.bodySmall,
              color = effectiveContentColor.copy(alpha = 0.7f),
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      }

      IconButton(
        onClick = { playerConnection.player.togglePlayPause() },
        modifier = Modifier.size(controlSize),
      ) {
        Icon(
          painter = painterResource(if (isPlaying) R.drawable.pause else R.drawable.play),
          contentDescription = null,
          tint = effectiveContentColor,
        )
      }

      if (!isInline) {
        IconButton(
          onClick = { playerConnection.player.seekToNext() },
          modifier = Modifier.size(controlSize),
        ) {
          Icon(
            painter = painterResource(R.drawable.skip_next),
            contentDescription = null,
            tint = effectiveContentColor,
          )
        }
      }
    }
  }
}
