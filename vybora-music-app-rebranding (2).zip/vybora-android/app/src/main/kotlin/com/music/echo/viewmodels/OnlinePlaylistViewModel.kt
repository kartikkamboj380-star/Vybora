package echo.music.iad1tya.viewmodels

import android.content.Context
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.music.innertube.YouTube
import com.music.innertube.models.Artist
import com.music.innertube.models.PlaylistItem
import com.music.innertube.models.SongItem
import com.music.innertube.models.YTItem
import com.music.innertube.models.filterVideoSongs
import com.music.innertube.pages.PodcastPage
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import echo.music.iad1tya.constants.HideVideoSongsKey
import echo.music.iad1tya.db.MusicDatabase
import echo.music.iad1tya.utils.PodcastProgress
import echo.music.iad1tya.utils.PodcastShowStore
import echo.music.iad1tya.utils.dataStore
import echo.music.iad1tya.utils.get
import echo.music.iad1tya.utils.reportException
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@HiltViewModel
class OnlinePlaylistViewModel
@Inject
constructor(
  @ApplicationContext private val context: Context,
  savedStateHandle: SavedStateHandle,
  database: MusicDatabase,
  private val podcastShows: PodcastShowStore,
) : ViewModel() {
  private val playlistId = savedStateHandle.get<String>("playlistId")!!

  val playlist = MutableStateFlow<PlaylistItem?>(null)
  val playlistSongs = MutableStateFlow<List<SongItem>>(emptyList())
  val relatedItems = MutableStateFlow<List<YTItem>>(emptyList())

  private val _isLoading = MutableStateFlow(true)
  val isLoading = _isLoading.asStateFlow()

  private val _error = MutableStateFlow<String?>(null)
  val error = _error.asStateFlow()

  private val _isLoadingMore = MutableStateFlow(false)
  val isLoadingMore = _isLoadingMore.asStateFlow()

  val dbPlaylist =
    database.playlistByBrowseId(playlistId).stateIn(viewModelScope, SharingStarted.Lazily, null)

  var continuation: String? = null
    private set

  private var proactiveLoadJob: Job? = null

  init {
    fetchInitialPlaylistData()
  }

  private fun fetchInitialPlaylistData() {
    viewModelScope.launch(Dispatchers.IO) {
      _isLoading.value = true
      _error.value = null
      continuation = null
      proactiveLoadJob?.cancel()

      YouTube.playlist(playlistId)
        .onSuccess { playlistPage ->
          playlist.value = playlistPage.playlist
          if (playlistPage.playlist.isPodcast) podcastShows.add(playlistId)
          playlistSongs.value = applySongFilters(playlistPage.songs)
          relatedItems.value = playlistPage.related ?: emptyList()
          continuation = playlistPage.songsContinuation
          _isLoading.value = false
          if (continuation != null) {
            startProactiveBackgroundLoading()
          }
        }
        .onFailure { throwable ->
          _error.value =
            throwable.message?.takeIf { it.isNotBlank() }
              ?: throwable::class.java.simpleName
              ?: "Failed to load playlist"
          _isLoading.value = false
          reportException(throwable)
        }
    }
  }

  /**
   * Loads further pages in the background, but only up to [PROACTIVE_LOAD_LIMIT]
   * songs: personal mixes are practically endless, and loading them whole made
   * the list (and any queue started from it) grow to thousands of songs. Beyond
   * the limit, pages load as the list is scrolled ([loadMoreSongs]).
   */
  private fun startProactiveBackgroundLoading() {
    proactiveLoadJob?.cancel()
    proactiveLoadJob =
      viewModelScope.launch(Dispatchers.IO) {
        var currentProactiveToken = continuation
        while (currentProactiveToken != null && isActive && playlistSongs.value.size < PROACTIVE_LOAD_LIMIT) {

          if (_isLoadingMore.value) {

            break
          }

          YouTube.playlistContinuation(currentProactiveToken)
            .onSuccess { playlistContinuationPage ->
              val currentSongs = playlistSongs.value.toMutableList()
              currentSongs.addAll(playlistContinuationPage.songs)
              playlistSongs.value = applySongFilters(currentSongs)
              currentProactiveToken = playlistContinuationPage.continuation

              this@OnlinePlaylistViewModel.continuation = currentProactiveToken
            }
            .onFailure { throwable ->
              reportException(throwable)
              currentProactiveToken = null
            }
        }
      }
  }

  fun loadMoreSongs() {
    if (_isLoadingMore.value) return

    val tokenForManualLoad = continuation ?: return

    proactiveLoadJob?.cancel()
    _isLoadingMore.value = true

    viewModelScope.launch(Dispatchers.IO) {
      YouTube.playlistContinuation(tokenForManualLoad)
        .onSuccess { playlistContinuationPage ->
          val currentSongs = playlistSongs.value.toMutableList()
          currentSongs.addAll(playlistContinuationPage.songs)
          playlistSongs.value = applySongFilters(currentSongs)
          continuation = playlistContinuationPage.continuation
        }
        .onFailure { throwable -> reportException(throwable) }
        .also {
          _isLoadingMore.value = false
          // This load cancelled the proactive one; resume it if still below the limit.
          if (continuation != null && playlistSongs.value.size < PROACTIVE_LOAD_LIMIT) {
            startProactiveBackgroundLoading()
          }
        }
    }
  }

  /**
   * Loads the remaining pages, up to [FULL_LOAD_LIMIT] songs, for what needs the
   * whole playlist rather than the part loaded so far: search, save, download.
   */
  suspend fun loadAllSongs(): List<SongItem> =
    withContext(Dispatchers.IO) {
      proactiveLoadJob?.cancel()
      _isLoadingMore.first { !it }
      while (playlistSongs.value.size < FULL_LOAD_LIMIT) {
        val token = continuation ?: break
        val result = YouTube.playlistContinuation(token)
        val page = result.getOrNull()
        if (page == null) {
          result.exceptionOrNull()?.let(::reportException)
          break
        }
        playlistSongs.value = applySongFilters(playlistSongs.value + page.songs)
        continuation = page.continuation
      }
      playlistSongs.value
    }

  fun retry() {
    proactiveLoadJob?.cancel()
    fetchInitialPlaylistData()
  }

  private fun applySongFilters(songs: List<SongItem>): List<SongItem> {
    val hideVideoSongs = context.dataStore.get(HideVideoSongsKey, false)
    val uniqueSongs = songs.distinctBy { it.id }.withPodcastShow()
    if (!hideVideoSongs) return uniqueSongs

    val filtered = uniqueSongs.filterVideoSongs(true)
    // If filtering hides everything, keep original list to avoid false "empty playlist" UX.
    return if (filtered.isEmpty() && uniqueSongs.isNotEmpty()) uniqueSongs else filtered
  }

  /** Episodes on later show pages do not name their show; credit it to this one. */
  private fun List<SongItem>.withPodcastShow(): List<SongItem> {
    val show = playlist.value?.takeIf { it.isPodcast } ?: return this
    val showArtist = Artist(name = show.title, id = PodcastPage.showBrowseId(show.id))
    val attributed = map { if (it.artists.isEmpty()) it.copy(artists = listOf(showArtist)) else it }
    attributed.forEach(PodcastProgress::mergeRemote)
    return attributed
  }

  override fun onCleared() {
    super.onCleared()
    proactiveLoadJob?.cancel()
  }

  private companion object {
    /** Songs loaded without the user scrolling; enough for typical playlists and shuffle. */
    const val PROACTIVE_LOAD_LIMIT = 200
    /** Cap for [loadAllSongs], as personal mixes never run out of pages. */
    const val FULL_LOAD_LIMIT = 5000
  }
}
