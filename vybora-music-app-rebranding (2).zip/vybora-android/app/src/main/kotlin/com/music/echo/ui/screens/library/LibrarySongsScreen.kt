package echo.music.iad1tya.ui.screens.library

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import echo.music.iad1tya.LocalPlayerAwareWindowInsets
import echo.music.iad1tya.LocalPlayerConnection
import echo.music.iad1tya.R
import echo.music.iad1tya.constants.CONTENT_TYPE_HEADER
import echo.music.iad1tya.constants.CONTENT_TYPE_SONG
import echo.music.iad1tya.constants.HideExplicitKey
import echo.music.iad1tya.constants.SongFilter
import echo.music.iad1tya.constants.SongFilterKey
import echo.music.iad1tya.constants.SongSortDescendingKey
import echo.music.iad1tya.constants.SongSortType
import echo.music.iad1tya.constants.SongSortTypeKey
import echo.music.iad1tya.constants.YtmSyncKey
import echo.music.iad1tya.extensions.toMediaItem
import echo.music.iad1tya.playback.queues.ListQueue
import echo.music.iad1tya.ui.component.ChipsRow
import echo.music.iad1tya.ui.component.HideOnScrollFAB
import echo.music.iad1tya.ui.component.LocalMenuState
import echo.music.iad1tya.ui.component.SongListItem
import echo.music.iad1tya.ui.component.SortHeader
import echo.music.iad1tya.ui.menu.SelectionSongMenu
import echo.music.iad1tya.ui.menu.SongMenu
import echo.music.iad1tya.utils.listItemShape
import echo.music.iad1tya.utils.rememberEnumPreference
import echo.music.iad1tya.utils.rememberPreference
import echo.music.iad1tya.viewmodels.LibrarySongsViewModel

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun LibrarySongsScreen(
  navController: NavController,
  onDeselect: () -> Unit,
  viewModel: LibrarySongsViewModel = hiltViewModel(),
) {
  val context = LocalContext.current
  val menuState = LocalMenuState.current
  val playerConnection = LocalPlayerConnection.current ?: return
  val haptic = LocalHapticFeedback.current
  val isPlaying by playerConnection.isEffectivelyPlaying.collectAsState()
  val mediaMetadata by playerConnection.mediaMetadata.collectAsState()

  val (sortType, onSortTypeChange) =
    rememberEnumPreference(SongSortTypeKey, SongSortType.CREATE_DATE)
  val (sortDescending, onSortDescendingChange) = rememberPreference(SongSortDescendingKey, true)

  val (ytmSync) = rememberPreference(YtmSyncKey, true)
  val hideExplicit by rememberPreference(key = HideExplicitKey, defaultValue = false)

  val songs by viewModel.allSongs.collectAsState()

  var filter by rememberEnumPreference(SongFilterKey, SongFilter.LIKED)

  var inSelectMode by rememberSaveable { mutableStateOf(false) }
  val selection = remember { mutableStateListOf<String>() }
  val onExitSelectionMode = {
    inSelectMode = false
    selection.clear()
  }

  LaunchedEffect(Unit) {
    if (ytmSync) {
      when (filter) {
        SongFilter.LIKED -> viewModel.syncLikedSongs()
        SongFilter.LIBRARY -> viewModel.syncLibrarySongs()
        SongFilter.UPLOADED -> viewModel.syncUploadedSongs()
        else -> return@LaunchedEffect
      }
    }
  }

  val lazyListState = rememberLazyListState()

  val backStackEntry by navController.currentBackStackEntryAsState()
  val scrollToTop =
    backStackEntry?.savedStateHandle?.getStateFlow("scrollToTop", false)?.collectAsState()

  LaunchedEffect(scrollToTop?.value) {
    if (scrollToTop?.value == true) {
      lazyListState.animateScrollToItem(0)
      backStackEntry?.savedStateHandle?.set("scrollToTop", false)
    }
  }

  val filteredSongs =
    if (hideExplicit) {
      songs.filter { !it.song.explicit }
    } else {
      songs
    }

  Box(
    modifier = Modifier.fillMaxSize(),
  ) {
    Box(
      modifier = Modifier.fillMaxSize(),
    ) {
      LazyColumn(
        state = lazyListState,
        contentPadding = LocalPlayerAwareWindowInsets.current.asPaddingValues(),
      ) {
        item(
          key = "filter",
          contentType = CONTENT_TYPE_HEADER,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Spacer(Modifier.width(12.dp))
            FilterChip(
              label = { Text(stringResource(R.string.songs)) },
              selected = true,
              colors =
                FilterChipDefaults.filterChipColors(
                  containerColor = MaterialTheme.colorScheme.surface
                ),
              onClick = onDeselect,
              shape = RoundedCornerShape(16.dp),
              leadingIcon = {
                Icon(painter = painterResource(R.drawable.close), contentDescription = "")
              },
              modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
            )
            ChipsRow(
              chips =
                listOf(
                  SongFilter.LIKED to stringResource(R.string.filter_liked),
                  SongFilter.LIBRARY to stringResource(R.string.filter_library),
                  SongFilter.UPLOADED to stringResource(R.string.filter_uploaded),
                  SongFilter.DOWNLOADED to stringResource(R.string.filter_downloaded),
                  SongFilter.EXPORTED to stringResource(R.string.action_exported),
                ),
              currentValue = filter,
              onValueUpdate = { filter = it },
              modifier = Modifier.weight(1f),
            )
          }
        }

        item(
          key = "header",
          contentType = CONTENT_TYPE_HEADER,
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 16.dp),
          ) {
            SortHeader(
              sortType = sortType,
              sortDescending = sortDescending,
              onSortTypeChange = onSortTypeChange,
              onSortDescendingChange = onSortDescendingChange,
              sortTypeText = { sortType ->
                when (sortType) {
                  SongSortType.CREATE_DATE -> R.string.sort_by_create_date
                  SongSortType.NAME -> R.string.sort_by_name
                  SongSortType.ARTIST -> R.string.sort_by_artist
                  SongSortType.PLAY_TIME -> R.string.sort_by_play_time
                }
              },
            )

            Spacer(Modifier.weight(1f))

            Text(
              text = pluralStringResource(R.plurals.n_song, filteredSongs.size, filteredSongs.size),
              style = MaterialTheme.typography.titleSmall,
              color = MaterialTheme.colorScheme.secondary,
            )
          }
        }

        itemsIndexed(
          items = filteredSongs,
          key = { _, item -> item.song.id },
          contentType = { _, _ -> CONTENT_TYPE_SONG },
        ) { index, song ->
          val onCheckedChange: (Boolean) -> Unit = {
            if (it) {
              selection.add(song.id)
            } else {
              selection.remove(song.id)
            }
          }
          SongListItem(
            song = song,
            showInLibraryIcon = true,
            isActive = song.id == mediaMetadata?.id,
            isPlaying = isPlaying,
            showLikedIcon = true,
            showDownloadIcon = filter != SongFilter.DOWNLOADED,
            showSize = filter == SongFilter.DOWNLOADED,
            shape = listItemShape(index, filteredSongs.size),
            trailingContent = {
              if (inSelectMode) {
                Checkbox(checked = selection.contains(song.id), onCheckedChange = onCheckedChange)
              } else {
                IconButton(
                  onClick = {
                    menuState.show {
                      SongMenu(
                        originalSong = song,
                        navController = navController,
                        onDismiss = menuState::dismiss,
                      )
                    }
                  },
                ) {
                  Icon(
                    painter = painterResource(R.drawable.more_vert),
                    contentDescription = null,
                  )
                }
              }
            },
            modifier =
              Modifier.fillMaxWidth()
                .combinedClickable(
                  onClick = {
                    if (inSelectMode) {
                      onCheckedChange(!selection.contains(song.id))
                    } else if (song.id == mediaMetadata?.id) {
                      playerConnection.togglePlayPause()
                    } else {
                      playerConnection.playQueue(
                        ListQueue(
                          title = context.getString(R.string.queue_all_songs),
                          items = filteredSongs.map { it.toMediaItem() },
                          startIndex = index,
                        ),
                      )
                    }
                  },
                  onLongClick = {
                    if (!inSelectMode) {
                      haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                      inSelectMode = true
                      onCheckedChange(true)
                    } else {
                      menuState.show {
                        SongMenu(
                          originalSong = song,
                          navController = navController,
                          onDismiss = menuState::dismiss,
                        )
                      }
                    }
                  }
                )
                .animateItem(),
          )
        }
      }

      androidx.compose.animation.AnimatedVisibility(
        visible = inSelectMode,
        enter = androidx.compose.animation.fadeIn(),
        exit = androidx.compose.animation.fadeOut(),
        modifier = Modifier.align(Alignment.TopCenter)
      ) {
        androidx.compose.material3.TopAppBar(
          title = {
            Text(pluralStringResource(R.plurals.n_selected, selection.size, selection.size))
          },
          navigationIcon = {
            IconButton(onClick = onExitSelectionMode) {
              Icon(painter = painterResource(R.drawable.close), contentDescription = null)
            }
          },
          actions = {
            Checkbox(
              checked = selection.size == filteredSongs.size && selection.isNotEmpty(),
              onCheckedChange = {
                if (selection.size == filteredSongs.size) {
                  selection.clear()
                } else {
                  selection.clear()
                  selection.addAll(filteredSongs.map { it.song.id })
                }
              }
            )
            IconButton(
              enabled = selection.isNotEmpty(),
              onClick = {
                menuState.show {
                  SelectionSongMenu(
                    songSelection = selection.mapNotNull { id -> songs.find { it.song.id == id } },
                    onDismiss = menuState::dismiss,
                    clearAction = onExitSelectionMode
                  )
                }
              }
            ) {
              Icon(painter = painterResource(R.drawable.more_vert), contentDescription = null)
            }
          },
          colors =
            TopAppBarDefaults.topAppBarColors(
              containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f)
            ),
          windowInsets = WindowInsets(0.dp)
        )
      }

      HideOnScrollFAB(
        visible = filteredSongs.isNotEmpty(),
        lazyListState = lazyListState,
        icon = R.drawable.shuffle,
        onClick = {
          playerConnection.playQueue(
            ListQueue(
              title = context.getString(R.string.queue_all_songs),
              items = filteredSongs.shuffled().map { it.toMediaItem() },
            ),
          )
        },
      )
    }
  }
}
