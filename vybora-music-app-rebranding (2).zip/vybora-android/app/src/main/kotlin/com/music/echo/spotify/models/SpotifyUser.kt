/*
 * EchoMusic (2026)
 * © Chartreux Westia — github.com/koiverse
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package echo.music.iad1tya.spotify.models

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class SpotifyUser(
  val id: String,
  @SerialName("display_name") val displayName: String? = null,
  val email: String? = null,
  val images: List<SpotifyImage> = emptyList(),
  val product: String? = null,
  val country: String? = null,
)

@Serializable
data class SpotifyImage(
  val url: String = "",
  val height: Int? = null,
  val width: Int? = null,
)
