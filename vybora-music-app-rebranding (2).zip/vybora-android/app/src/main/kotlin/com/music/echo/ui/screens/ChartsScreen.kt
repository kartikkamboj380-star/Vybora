package echo.music.iad1tya.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyHorizontalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.navigation.NavController
import com.music.innertube.models.SongItem
import com.music.innertube.models.WatchEndpoint
import echo.music.iad1tya.LocalPlayerAwareWindowInsets
import echo.music.iad1tya.LocalPlayerConnection
import echo.music.iad1tya.R
import echo.music.iad1tya.constants.ListItemHeight
import echo.music.iad1tya.models.toMediaMetadata
import echo.music.iad1tya.playback.queues.YouTubeQueue
import echo.music.iad1tya.ui.component.IconButton
import echo.music.iad1tya.ui.component.LocalMenuState
import echo.music.iad1tya.ui.component.NavigationTitle
import echo.music.iad1tya.ui.component.YouTubeGridItem
import echo.music.iad1tya.ui.component.YouTubeListItem
import echo.music.iad1tya.ui.component.shimmer.GridItemPlaceHolder
import echo.music.iad1tya.ui.component.shimmer.ShimmerHost
import echo.music.iad1tya.ui.component.shimmer.TextPlaceholder
import echo.music.iad1tya.ui.menu.YouTubeSongMenu
import echo.music.iad1tya.ui.utils.SnapLayoutInfoProvider
import echo.music.iad1tya.ui.utils.backToMain
import echo.music.iad1tya.utils.listItemShape
import echo.music.iad1tya.viewmodels.ChartsViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ChartsScreen(
  navController: NavController,
  viewModel: ChartsViewModel = hiltViewModel(),
) {
  val menuState = LocalMenuState.current
  val haptic = LocalHapticFeedback.current
  val playerConnection = LocalPlayerConnection.current ?: return
  val isPlaying by playerConnection.isEffectivelyPlaying.collectAsState()
  val mediaMetadata by playerConnection.mediaMetadata.collectAsState()

  val chartsPage by viewModel.chartsPage.collectAsState()
  val isLoading by viewModel.isLoading.collectAsState()

  val lazyListState = rememberLazyListState()
  val coroutineScope = rememberCoroutineScope()

  LaunchedEffect(Unit) {
    if (chartsPage == null) {
      viewModel.loadCharts()
    }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text(stringResource(R.string.charts)) },
        navigationIcon = {
          IconButton(
            onClick = { navController.navigateUp() },
            onLongClick = { navController.backToMain() }
          ) {
            Icon(
              painter = painterResource(R.drawable.arrow_back),
              contentDescription = null,
            )
          }
        },
      )
    }
  ) { paddingValues ->
    BoxWithConstraints(
      modifier = Modifier.fillMaxSize().padding(paddingValues),
    ) {
      if (isLoading || chartsPage == null) {
        ShimmerHost(
          modifier = Modifier.fillMaxSize(),
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            TextPlaceholder(
              height = 36.dp,
              modifier = Modifier.padding(12.dp).fillMaxWidth(0.5f),
            )
            BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
              val horizontalLazyGridItemWidthFactor =
                if (maxWidth * 0.475f >= 320.dp) 0.475f else 0.9f
              val horizontalLazyGridItemWidth = maxWidth * horizontalLazyGridItemWidthFactor

              LazyHorizontalGrid(
                rows = GridCells.Fixed(4),
                contentPadding = PaddingValues(start = 4.dp),
                modifier = Modifier.fillMaxWidth().height(ListItemHeight * 4),
              ) {
                items(4) {
                  Row(
                    modifier = Modifier.width(horizontalLazyGridItemWidth).padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Box(
                      modifier =
                        Modifier.size(ListItemHeight - 16.dp)
                          .clip(RoundedCornerShape(4.dp))
                          .background(MaterialTheme.colorScheme.onSurface),
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(
                      modifier = Modifier.fillMaxHeight(),
                      verticalArrangement = Arrangement.Center,
                    ) {
                      Box(
                        modifier =
                          Modifier.height(16.dp)
                            .width(120.dp)
                            .background(MaterialTheme.colorScheme.onSurface),
                      )
                      Spacer(modifier = Modifier.height(8.dp))
                      Box(
                        modifier =
                          Modifier.height(12.dp)
                            .width(80.dp)
                            .background(MaterialTheme.colorScheme.onSurface),
                      )
                    }
                  }
                }
              }
            }
            TextPlaceholder(
              height = 36.dp,
              modifier = Modifier.padding(vertical = 12.dp, horizontal = 12.dp).width(250.dp),
            )
            Row { repeat(2) { GridItemPlaceHolder() } }
          }
        }
      } else {
        LazyColumn(
          state = lazyListState,
          contentPadding =
            LocalPlayerAwareWindowInsets.current
              .only(WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom)
              .asPaddingValues(),
        ) {
          chartsPage
            ?.sections
            ?.filter { it.title != "Top music videos" }
            ?.forEach { section ->
              item(key = "section_title_${section.title}") {
                NavigationTitle(
                  title =
                    when (section.title) {
                      "Trending" -> stringResource(R.string.trending)
                      else -> section.title.ifEmpty { stringResource(R.string.charts) }
                    },
                  modifier = Modifier.animateItem(),
                )
              }
              item(key = "section_content_${section.title}") {
                BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                  val horizontalLazyGridItemWidthFactor =
                    if (maxWidth * 0.475f >= 320.dp) 0.475f else 0.9f
                  val horizontalLazyGridItemWidth = maxWidth * horizontalLazyGridItemWidthFactor

                  val lazyGridState = rememberLazyGridState()
                  val snapLayoutInfoProvider =
                    remember(lazyGridState) {
                      SnapLayoutInfoProvider(
                        lazyGridState = lazyGridState,
                        positionInLayout = { layoutSize, itemSize ->
                          (layoutSize * horizontalLazyGridItemWidthFactor / 2f - itemSize / 2f)
                        },
                      )
                    }

                  LazyHorizontalGrid(
                    state = lazyGridState,
                    rows = GridCells.Fixed(4),
                    flingBehavior = rememberSnapFlingBehavior(snapLayoutInfoProvider),
                    contentPadding =
                      WindowInsets.systemBars.only(WindowInsetsSides.Horizontal).asPaddingValues(),
                    modifier = Modifier.fillMaxWidth().height(ListItemHeight * 4).animateItem(),
                  ) {
                    itemsIndexed(
                      items = section.items.filterIsInstance<SongItem>().distinctBy { it.id },
                      key = { _, it -> it.id },
                    ) { index, song ->
                      YouTubeListItem(
                        item = song,
                        isActive = song.id == mediaMetadata?.id,
                        isPlaying = isPlaying,
                        isSwipeable = false,
                        shape = listItemShape(index % 4, 4),
                        trailingContent = {
                          IconButton(
                            onClick = {
                              menuState.show {
                                YouTubeSongMenu(
                                  song = song,
                                  navController = navController,
                                  onDismiss = menuState::dismiss,
                                )
                              }
                            },
                          ) {
                            Icon(
                              painter = painterResource(R.drawable.more_vert),
                              contentDescription = null,
                            )
                          }
                        },
                        modifier =
                          Modifier.width(horizontalLazyGridItemWidth)
                            .combinedClickable(
                              onClick = {
                                if (song.id == mediaMetadata?.id) {
                                  playerConnection.togglePlayPause()
                                } else {
                                  playerConnection.playQueue(
                                    YouTubeQueue(
                                      endpoint = WatchEndpoint(videoId = song.id),
                                      preloadItem = song.toMediaMetadata(),
                                    ),
                                  )
                                }
                              },
                              onLongClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                menuState.show {
                                  YouTubeSongMenu(
                                    song = song,
                                    navController = navController,
                                    onDismiss = menuState::dismiss,
                                  )
                                }
                              },
                            ),
                      )
                    }
                  }
                }
              }
            }

          chartsPage
            ?.sections
            ?.find { it.title == "Top music videos" }
            ?.let { topVideosSection ->
              item(key = "top_videos_title") {
                NavigationTitle(
                  title = stringResource(R.string.top_music_videos),
                  modifier = Modifier.animateItem(),
                )
              }
              item(key = "top_videos_content") {
                LazyRow(
                  contentPadding =
                    WindowInsets.systemBars.only(WindowInsetsSides.Horizontal).asPaddingValues(),
                  modifier = Modifier.animateItem(),
                ) {
                  items(
                    items =
                      topVideosSection.items.filterIsInstance<SongItem>().distinctBy { it.id },
                    key = { it.id },
                  ) { video ->
                    YouTubeGridItem(
                      item = video,
                      isActive = video.id == mediaMetadata?.id,
                      isPlaying = isPlaying,
                      coroutineScope = coroutineScope,
                      modifier =
                        Modifier.combinedClickable(
                            onClick = {
                              if (video.id == mediaMetadata?.id) {
                                playerConnection.togglePlayPause()
                              } else {
                                playerConnection.playQueue(
                                  YouTubeQueue(
                                    endpoint = WatchEndpoint(videoId = video.id),
                                    preloadItem = video.toMediaMetadata(),
                                  ),
                                )
                              }
                            },
                            onLongClick = {
                              haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                              menuState.show {
                                YouTubeSongMenu(
                                  song = video,
                                  navController = navController,
                                  onDismiss = menuState::dismiss,
                                )
                              }
                            },
                          )
                          .animateItem(),
                    )
                  }
                }
              }
            }
        }
      }
    }
  }
}
