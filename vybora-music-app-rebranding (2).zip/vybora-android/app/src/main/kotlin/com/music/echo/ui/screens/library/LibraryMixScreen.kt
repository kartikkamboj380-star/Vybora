package echo.music.iad1tya.ui.screens.library

import android.net.Uri
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.PullToRefreshDefaults
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import echo.music.iad1tya.LocalPlayerAwareWindowInsets
import echo.music.iad1tya.LocalPlayerConnection
import echo.music.iad1tya.R
import echo.music.iad1tya.constants.AlbumViewTypeKey
import echo.music.iad1tya.constants.CONTENT_TYPE_HEADER
import echo.music.iad1tya.constants.CONTENT_TYPE_PLAYLIST
import echo.music.iad1tya.constants.GridItemSize
import echo.music.iad1tya.constants.GridItemsSizeKey
import echo.music.iad1tya.constants.GridThumbnailHeight
import echo.music.iad1tya.constants.LibraryViewType
import echo.music.iad1tya.constants.MixSortDescendingKey
import echo.music.iad1tya.constants.MixSortType
import echo.music.iad1tya.constants.MixSortTypeKey
import echo.music.iad1tya.constants.ShowBottomPlaylistKey
import echo.music.iad1tya.constants.ShowCachedPlaylistKey
import echo.music.iad1tya.constants.ShowDownloadedPlaylistKey
import echo.music.iad1tya.constants.ShowExportedPlaylistKey
import echo.music.iad1tya.constants.ShowLikedPlaylistKey
import echo.music.iad1tya.constants.ShowTopPlaylistKey
import echo.music.iad1tya.constants.ThumbnailCornerRadius
import echo.music.iad1tya.constants.ListThumbnailSize
import echo.music.iad1tya.constants.YtmSyncKey
import echo.music.iad1tya.db.entities.Album
import echo.music.iad1tya.db.entities.Artist
import echo.music.iad1tya.db.entities.Playlist
import echo.music.iad1tya.db.entities.PlaylistEntity
import echo.music.iad1tya.extensions.reversed
import echo.music.iad1tya.spotify.SpotifyMapper
import echo.music.iad1tya.ui.component.AlbumGridItem
import echo.music.iad1tya.ui.component.AlbumListItem
import echo.music.iad1tya.ui.component.ArtistGridItem
import echo.music.iad1tya.ui.component.ArtistListItem
import echo.music.iad1tya.ui.component.AutoPlaylistButton
import echo.music.iad1tya.ui.component.GridItem
import echo.music.iad1tya.ui.component.ListItem
import echo.music.iad1tya.ui.component.LocalMenuState
import echo.music.iad1tya.ui.component.PlaylistGridItem
import echo.music.iad1tya.ui.component.PlaylistListItem
import echo.music.iad1tya.ui.component.SortHeader
import echo.music.iad1tya.ui.menu.AlbumMenu
import echo.music.iad1tya.ui.menu.ArtistMenu
import echo.music.iad1tya.ui.menu.PlaylistMenu
import echo.music.iad1tya.utils.joinByBullet
import echo.music.iad1tya.utils.listItemShape
import echo.music.iad1tya.utils.rememberEnumPreference
import echo.music.iad1tya.utils.rememberPreference
import echo.music.iad1tya.viewmodels.LibraryMixViewModel
import coil3.compose.AsyncImage
import java.text.Collator
import java.time.LocalDateTime
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@OptIn(
  ExperimentalFoundationApi::class,
  ExperimentalMaterial3Api::class,
  ExperimentalMaterial3ExpressiveApi::class
)
@Composable
fun LibraryMixScreen(
  navController: NavController,
  filterContent: @Composable () -> Unit,
  viewModel: LibraryMixViewModel = hiltViewModel(),
  spotifyViewModel: LibrarySpotifyViewModel = hiltViewModel(),
) {
  val menuState = LocalMenuState.current
  val haptic = LocalHapticFeedback.current
  val playerConnection = LocalPlayerConnection.current ?: return
  val isPlaying by playerConnection.isEffectivelyPlaying.collectAsState()
  val mediaMetadata by playerConnection.mediaMetadata.collectAsState()

  val spotifyUiState by spotifyViewModel.uiState.collectAsState()
  val lifecycleOwner = LocalLifecycleOwner.current

  DisposableEffect(lifecycleOwner) {
    val observer = LifecycleEventObserver { _, event ->
      if (event == Lifecycle.Event.ON_RESUME) {
        spotifyViewModel.refresh()
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose {
      lifecycleOwner.lifecycle.removeObserver(observer)
    }
  }

  var viewType by rememberEnumPreference(AlbumViewTypeKey, LibraryViewType.GRID)
  val (sortType, onSortTypeChange) = rememberEnumPreference(MixSortTypeKey, MixSortType.CREATE_DATE)
  val (sortDescending, onSortDescendingChange) = rememberPreference(MixSortDescendingKey, true)
  val gridItemSize by rememberEnumPreference(GridItemsSizeKey, GridItemSize.BIG)

  val (ytmSync) = rememberPreference(YtmSyncKey, true)

  val topSize by viewModel.topValue.collectAsState(initial = 50)
  val likedPlaylist =
    Playlist(
      playlist =
        PlaylistEntity(id = UUID.randomUUID().toString(), name = stringResource(R.string.liked)),
      songCount = 0,
      songThumbnails = emptyList(),
    )

  val downloadPlaylist =
    Playlist(
      playlist =
        PlaylistEntity(id = UUID.randomUUID().toString(), name = stringResource(R.string.offline)),
      songCount = 0,
      songThumbnails = emptyList(),
    )

  val topPlaylist =
    Playlist(
      playlist =
        PlaylistEntity(
          id = UUID.randomUUID().toString(),
          name = stringResource(R.string.my_top) + " $topSize"
        ),
      songCount = 0,
      songThumbnails = emptyList(),
    )

  val cachePlaylist =
    Playlist(
      playlist =
        PlaylistEntity(
          id = UUID.randomUUID().toString(),
          name = stringResource(R.string.cached_playlist)
        ),
      songCount = 0,
      songThumbnails = emptyList(),
    )

  val uploadedPlaylist =
    Playlist(
      playlist =
        PlaylistEntity(
          id = UUID.randomUUID().toString(),
          name = stringResource(R.string.uploaded_playlist)
        ),
      songCount = 0,
      songThumbnails = emptyList(),
    )

  val (showLiked) = rememberPreference(ShowLikedPlaylistKey, true)
  val (showDownloaded) = rememberPreference(ShowDownloadedPlaylistKey, true)
  val (showExported) = rememberPreference(ShowExportedPlaylistKey, true)
  val (showTop) = rememberPreference(ShowTopPlaylistKey, true)
  val (showBottom) = rememberPreference(ShowBottomPlaylistKey, true)
  val (showCached) = rememberPreference(ShowCachedPlaylistKey, true)

  val albums = viewModel.albums.collectAsState()
  val artist = viewModel.artists.collectAsState()
  val playlist = viewModel.playlists.collectAsState()

  val collator = Collator.getInstance(Locale.getDefault())
  collator.strength = Collator.PRIMARY

  fun <T> List<T>.sortItems(): List<T> {
    return when (sortType) {
      MixSortType.CREATE_DATE ->
        this.sortedBy { item ->
          when (item) {
            is Album -> item.album.bookmarkedAt
            is Artist -> item.artist.bookmarkedAt
            is Playlist -> item.playlist.createdAt
            else -> LocalDateTime.now()
          }
        }
      MixSortType.NAME ->
        this.sortedWith(
          compareBy(collator) { item ->
            when (item) {
              is Album -> item.album.title
              is Artist -> item.artist.name
              is Playlist -> item.playlist.name
              else -> ""
            }
          },
        )
      MixSortType.LAST_UPDATED ->
        this.sortedBy { item ->
          when (item) {
            is Album -> item.album.lastUpdateTime
            is Artist -> item.artist.lastUpdateTime
            is Playlist -> item.playlist.lastUpdateTime
            else -> LocalDateTime.now()
          }
        }
    }.reversed(sortDescending)
  }

  val sortedPlaylists = playlist.value.sortItems()
  val pinnedPlaylists = sortedPlaylists.filter { it.playlist.isPinned }
  val otherPlaylists = sortedPlaylists.filterNot { it.playlist.isPinned }
  val sortedArtists = artist.value.sortItems()
  val sortedAlbums = albums.value.sortItems()

  val coroutineScope = rememberCoroutineScope()

  val lazyListState = rememberLazyListState()
  val lazyGridState = rememberLazyGridState()
  val backStackEntry by navController.currentBackStackEntryAsState()
  val scrollToTop =
    backStackEntry?.savedStateHandle?.getStateFlow("scrollToTop", false)?.collectAsState()

  LaunchedEffect(scrollToTop?.value) {
    if (scrollToTop?.value == true) {
      when (viewType) {
        LibraryViewType.LIST -> lazyListState.animateScrollToItem(0)
        LibraryViewType.GRID -> lazyGridState.animateScrollToItem(0)
      }
      backStackEntry?.savedStateHandle?.set("scrollToTop", false)
    }
  }

  LaunchedEffect(Unit) {
    if (ytmSync) {
      withContext(Dispatchers.IO) { viewModel.syncAllLibrary() }
    }
  }

  val headerContent =
    @Composable {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(start = 16.dp),
      ) {
        SortHeader(
          sortType = sortType,
          sortDescending = sortDescending,
          onSortTypeChange = onSortTypeChange,
          onSortDescendingChange = onSortDescendingChange,
          sortTypeText = { sortType ->
            when (sortType) {
              MixSortType.CREATE_DATE -> R.string.sort_by_create_date
              MixSortType.LAST_UPDATED -> R.string.sort_by_last_updated
              MixSortType.NAME -> R.string.sort_by_name
            }
          },
        )

        Spacer(Modifier.weight(1f))

        Spacer(modifier = Modifier.width(16.dp))
      }
    }

  val isRefreshing by viewModel.isRefreshing.collectAsState()
  val pullRefreshState = rememberPullToRefreshState()

  PullToRefreshBox(
    state = pullRefreshState,
    isRefreshing = isRefreshing,
    onRefresh = viewModel::refresh,
    indicator = {
      PullToRefreshDefaults.LoadingIndicator(
        state = pullRefreshState,
        isRefreshing = isRefreshing,
        modifier = Modifier.align(Alignment.TopCenter),
      )
    }
  ) {
    when (viewType) {
      LibraryViewType.LIST ->
        LazyColumn(
          state = lazyListState,
          contentPadding = LocalPlayerAwareWindowInsets.current.asPaddingValues(),
        ) {
          item(
            key = "filter",
            contentType = CONTENT_TYPE_HEADER,
          ) {
            filterContent()
          }

          item(
            key = "header",
            contentType = CONTENT_TYPE_HEADER,
          ) {
            headerContent()
          }

          item(
            key = "auto_playlists_grid",
            contentType = CONTENT_TYPE_HEADER,
          ) {
            FlowRow(
              maxItemsInEachRow = 2,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp),
              modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
              val itemModifier = Modifier.weight(1f)
              if (showLiked) {
                AutoPlaylistButton(
                  title = stringResource(R.string.liked),
                  icon = R.drawable.favorite,
                  iconTint = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                  onClick = { navController.navigate("auto_playlist/liked") },
                  modifier = itemModifier
                )
              }
              if (showDownloaded) {
                AutoPlaylistButton(
                  title = stringResource(R.string.offline),
                  icon = R.drawable.offline,
                  iconTint = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                  onClick = { navController.navigate("auto_playlist/downloaded") },
                  modifier = itemModifier
                )
              }
              if (showExported) {
                AutoPlaylistButton(
                  title = stringResource(R.string.action_exported),
                  icon = R.drawable.download,
                  iconTint = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                  onClick = { navController.navigate("auto_playlist/exported") },
                  modifier = itemModifier
                )
              }
              if (showCached) {
                AutoPlaylistButton(
                  title = stringResource(R.string.cached_playlist),
                  icon = R.drawable.cached,
                  iconTint = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                  onClick = { navController.navigate("cache_playlist/cached") },
                  modifier = itemModifier
                )
              }

              if (showTop) {
                AutoPlaylistButton(
                  title = stringResource(R.string.my_top) + " $topSize",
                  icon = R.drawable.trending_up,
                  iconTint = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                  onClick = { navController.navigate("top_playlist/$topSize") },
                  modifier = itemModifier
                )
              }
              if (showBottom) {
                AutoPlaylistButton(
                  title = stringResource(R.string.my_bottom) + " 50",
                  icon = R.drawable.trending_down,
                  iconTint = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                  onClick = { navController.navigate("bottom_playlist/50") },
                  modifier = itemModifier
                )
              }
              AutoPlaylistButton(
                title = stringResource(R.string.filter_local),
                icon = R.drawable.snippet_folder,
                iconTint = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                onClick = { navController.navigate("local_songs") },
                modifier = itemModifier
              )
              AutoPlaylistButton(
                title = "Taste Mix",
                icon = R.drawable.playlist_play,
                iconTint = androidx.compose.material3.MaterialTheme.colorScheme.primary,
                onClick = { navController.navigate("generate") },
                modifier = itemModifier
              )
            }
          }

          item(
            key = "playlists_header",
            contentType = CONTENT_TYPE_HEADER,
          ) {
            androidx.compose.material3.Text(
              text = stringResource(R.string.filter_playlists),
              style = androidx.compose.material3.MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp)
            )
          }

          val allPlaylists = pinnedPlaylists + otherPlaylists
          items(
            items = allPlaylists.distinctBy { it.id },
            key = { "playlist_${it.id}" },
            contentType = { CONTENT_TYPE_PLAYLIST },
          ) { item ->
            PlaylistListItem(
              playlist = item,
              trailingContent = {
                IconButton(
                  onClick = {
                    menuState.show {
                      PlaylistMenu(
                        playlist = item,
                        coroutineScope = coroutineScope,
                        onDismiss = menuState::dismiss,
                      )
                    }
                  },
                ) {
                  Icon(
                    painter = painterResource(R.drawable.more_vert),
                    contentDescription = null,
                  )
                }
              },
              modifier =
                Modifier.fillMaxWidth()
                  .combinedClickable(
                    onClick = { navController.navigate("local_playlist/${item.id}") },
                    onLongClick = {
                      haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                      menuState.show {
                        PlaylistMenu(
                          playlist = item,
                          coroutineScope = coroutineScope,
                          onDismiss = menuState::dismiss,
                        )
                      }
                    },
                  )
                  .animateItem(),
            )
          }

          item(
            key = "spotify_playlists_header",
            contentType = CONTENT_TYPE_HEADER,
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 8.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  painter = painterResource(R.drawable.ic_spotify),
                  contentDescription = null,
                  tint = Color(0xFF1DB954),
                  modifier = Modifier.size(22.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                  text = stringResource(R.string.spotify_playlists_title),
                  style = MaterialTheme.typography.titleLarge,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onSurface,
                )
              }
              if (spotifyUiState.isAuthenticated) {
                val total = spotifyUiState.playlists.size + 1
                Text(
                  text = pluralStringResource(R.plurals.n_playlist, total, total),
                  style = MaterialTheme.typography.titleSmall,
                  color = MaterialTheme.colorScheme.secondary,
                )
              }
            }
          }

          if (!spotifyUiState.isAuthenticated) {
            item(key = "spotify_connect_banner") {
              SpotifyConnectBanner(
                onConnect = { navController.navigate("settings/spotify_import") },
                onRefresh = { spotifyViewModel.refresh() }
              )
            }
          } else {
            val totalPlaylists = spotifyUiState.playlists.size + 1
            val songCount = spotifyUiState.likedSongsCount ?: 0
            item(key = "spotify_liked_songs") {
              ListItem(
                title = stringResource(R.string.spotify_liked_songs),
                subtitle = {
                  val sub = joinByBullet(
                    "Spotify",
                    pluralStringResource(R.plurals.n_song, songCount, songCount),
                  )
                  Text(
                    text = sub,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                },
                thumbnailContent = {
                  Box(
                    modifier = Modifier
                      .size(ListThumbnailSize)
                      .clip(RoundedCornerShape(ThumbnailCornerRadius))
                      .background(
                        Brush.linearGradient(
                          listOf(
                            Color(0xFF450AF5),
                            Color(0xFF8E8EE5),
                            Color(0xFFABEDD8),
                          )
                        )
                      ),
                    contentAlignment = Alignment.Center,
                  ) {
                    Icon(
                      painter = painterResource(R.drawable.favorite),
                      contentDescription = null,
                      tint = Color.White,
                      modifier = Modifier.size(24.dp),
                    )
                    AsyncImage(
                      model = SPOTIFY_LIKED_SONGS_COVER,
                      contentDescription = null,
                      contentScale = ContentScale.Crop,
                      modifier = Modifier.fillMaxSize(),
                    )
                  }
                },
                trailingContent = {
                  Icon(
                    painter = painterResource(R.drawable.ic_push_pin),
                    contentDescription = "Pinned",
                    tint = Color(0xFF1DB954),
                    modifier = Modifier.size(18.dp).padding(end = 4.dp),
                  )
                },
                shape = listItemShape(0, totalPlaylists),
                modifier = Modifier
                  .fillMaxWidth()
                  .clickable {
                    val titleEnc = Uri.encode("Liked Songs")
                    val coverEnc = Uri.encode(SPOTIFY_LIKED_SONGS_COVER)
                    navController.navigate("spotify_playlist/liked?title=$titleEnc&cover=$coverEnc")
                  },
              )
            }

            itemsIndexed(
              items = spotifyUiState.playlists,
              key = { _, pl -> "spotify_${pl.id}" }
            ) { index, spPlaylist ->
              val coverUrl = SpotifyMapper.getPlaylistThumbnail(spPlaylist)
              val owner = spPlaylist.owner?.displayName?.takeIf { it.isNotBlank() }
              val countText = spPlaylist.tracks?.total?.let { "$it songs" }

              ListItem(
                title = spPlaylist.name,
                subtitle = {
                  val sub = joinByBullet(owner, countText)
                  if (sub.isNotBlank()) {
                    Text(
                      text = sub,
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                  }
                },
                thumbnailContent = {
                  AsyncImage(
                    model = coverUrl,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                      .size(ListThumbnailSize)
                      .clip(RoundedCornerShape(ThumbnailCornerRadius))
                      .background(MaterialTheme.colorScheme.surfaceContainerHighest),
                  )
                },
                shape = listItemShape(index + 1, totalPlaylists),
                modifier = Modifier
                  .fillMaxWidth()
                  .clickable {
                    val titleEnc = Uri.encode(spPlaylist.name)
                    val coverEnc = Uri.encode(coverUrl.orEmpty())
                    navController.navigate("spotify_playlist/${spPlaylist.id}?title=$titleEnc&cover=$coverEnc")
                  },
              )
            }
          }

          if (sortedArtists.isNotEmpty()) {
            item(
              key = "artists_header",
              contentType = CONTENT_TYPE_HEADER,
            ) {
              androidx.compose.material3.Text(
                text = stringResource(R.string.filter_artists),
                style = androidx.compose.material3.MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp)
              )
            }

            items(
              items = sortedArtists.distinctBy { it.id },
              key = { "artist_${it.id}" },
              contentType = { "artist" },
            ) { item ->
              ArtistListItem(
                artist = item,
                trailingContent = {
                  IconButton(
                    onClick = {
                      menuState.show {
                        ArtistMenu(
                          originalArtist = item,
                          coroutineScope = coroutineScope,
                          onDismiss = menuState::dismiss,
                        )
                      }
                    },
                  ) {
                    Icon(
                      painter = painterResource(R.drawable.more_vert),
                      contentDescription = null,
                    )
                  }
                },
                modifier =
                  Modifier.fillMaxWidth()
                    .combinedClickable(
                      onClick = { navController.navigate("artist/${item.id}") },
                      onLongClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        menuState.show {
                          ArtistMenu(
                            originalArtist = item,
                            coroutineScope = coroutineScope,
                            onDismiss = menuState::dismiss,
                          )
                        }
                      },
                    )
                    .animateItem(),
              )
            }
          }

          if (sortedAlbums.isNotEmpty()) {
            item(
              key = "albums_header",
              contentType = CONTENT_TYPE_HEADER,
            ) {
              androidx.compose.material3.Text(
                text = stringResource(R.string.filter_albums),
                style = androidx.compose.material3.MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp)
              )
            }

            items(
              items = sortedAlbums.distinctBy { it.id },
              key = { "album_${it.id}" },
              contentType = { "album" },
            ) { item ->
              AlbumListItem(
                album = item,
                isActive = item.id == mediaMetadata?.album?.id,
                isPlaying = isPlaying,
                trailingContent = {
                  IconButton(
                    onClick = {
                      menuState.show {
                        AlbumMenu(
                          originalAlbum = item,
                          navController = navController,
                          onDismiss = menuState::dismiss,
                        )
                      }
                    },
                  ) {
                    Icon(
                      painter = painterResource(R.drawable.more_vert),
                      contentDescription = null,
                    )
                  }
                },
                modifier =
                  Modifier.fillMaxWidth()
                    .combinedClickable(
                      onClick = { navController.navigate("album/${item.id}") },
                      onLongClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        menuState.show {
                          AlbumMenu(
                            originalAlbum = item,
                            navController = navController,
                            onDismiss = menuState::dismiss,
                          )
                        }
                      },
                    )
                    .animateItem(),
              )
            }
          }
        }
      LibraryViewType.GRID ->
        LazyVerticalGrid(
          state = lazyGridState,
          columns =
            GridCells.Adaptive(
              minSize =
                GridThumbnailHeight + if (gridItemSize == GridItemSize.BIG) 24.dp else (-24).dp,
            ),
          contentPadding = LocalPlayerAwareWindowInsets.current.asPaddingValues(),
        ) {
          item(
            key = "filter",
            span = { GridItemSpan(maxLineSpan) },
            contentType = CONTENT_TYPE_HEADER,
          ) {
            filterContent()
          }

          item(
            key = "header",
            span = { GridItemSpan(maxLineSpan) },
            contentType = CONTENT_TYPE_HEADER,
          ) {
            headerContent()
          }

          item(
            key = "auto_playlists_grid",
            span = { GridItemSpan(maxLineSpan) },
            contentType = CONTENT_TYPE_HEADER,
          ) {
            FlowRow(
              maxItemsInEachRow = 2,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp),
              modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
              val itemModifier = Modifier.weight(1f)
              if (showLiked) {
                AutoPlaylistButton(
                  title = stringResource(R.string.liked),
                  icon = R.drawable.favorite,
                  iconTint = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                  onClick = { navController.navigate("auto_playlist/liked") },
                  modifier = itemModifier
                )
              }
              if (showDownloaded) {
                AutoPlaylistButton(
                  title = stringResource(R.string.offline),
                  icon = R.drawable.offline,
                  iconTint = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                  onClick = { navController.navigate("auto_playlist/downloaded") },
                  modifier = itemModifier
                )
              }
              if (showExported) {
                AutoPlaylistButton(
                  title = stringResource(R.string.action_exported),
                  icon = R.drawable.download,
                  iconTint = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                  onClick = { navController.navigate("auto_playlist/exported") },
                  modifier = itemModifier
                )
              }
              if (showCached) {
                AutoPlaylistButton(
                  title = stringResource(R.string.cached_playlist),
                  icon = R.drawable.cached,
                  iconTint = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                  onClick = { navController.navigate("cache_playlist/cached") },
                  modifier = itemModifier
                )
              }

              if (showTop) {
                AutoPlaylistButton(
                  title = stringResource(R.string.my_top) + " $topSize",
                  icon = R.drawable.trending_up,
                  iconTint = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                  onClick = { navController.navigate("top_playlist/$topSize") },
                  modifier = itemModifier
                )
              }
              if (showBottom) {
                AutoPlaylistButton(
                  title = stringResource(R.string.my_bottom) + " 50",
                  icon = R.drawable.trending_down,
                  iconTint = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                  onClick = { navController.navigate("bottom_playlist/50") },
                  modifier = itemModifier
                )
              }
              AutoPlaylistButton(
                title = stringResource(R.string.filter_local),
                icon = R.drawable.snippet_folder,
                iconTint = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                onClick = { navController.navigate("local_songs") },
                modifier = itemModifier
              )
              AutoPlaylistButton(
                title = "Taste Mix",
                icon = R.drawable.playlist_play,
                iconTint = androidx.compose.material3.MaterialTheme.colorScheme.primary,
                onClick = { navController.navigate("generate") },
                modifier = itemModifier
              )
            }
          }

          item(
            key = "playlists_header",
            span = { GridItemSpan(maxLineSpan) },
            contentType = CONTENT_TYPE_HEADER,
          ) {
            androidx.compose.material3.Text(
              text = stringResource(R.string.filter_playlists),
              style = androidx.compose.material3.MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp)
            )
          }

          val allPlaylists = pinnedPlaylists + otherPlaylists
          items(
            items = allPlaylists.distinctBy { it.id },
            key = { "playlist_${it.id}" },
            contentType = { CONTENT_TYPE_PLAYLIST },
          ) { item ->
            PlaylistGridItem(
              playlist = item,
              fillMaxWidth = true,
              modifier =
                Modifier.fillMaxWidth()
                  .combinedClickable(
                    onClick = { navController.navigate("local_playlist/${item.id}") },
                    onLongClick = {
                      haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                      menuState.show {
                        PlaylistMenu(
                          playlist = item,
                          coroutineScope = coroutineScope,
                          onDismiss = menuState::dismiss,
                        )
                      }
                    },
                  )
                  .animateItem(),
            )
          }

          item(
            key = "spotify_playlists_header",
            span = { GridItemSpan(maxLineSpan) },
            contentType = CONTENT_TYPE_HEADER,
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 8.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  painter = painterResource(R.drawable.ic_spotify),
                  contentDescription = null,
                  tint = Color(0xFF1DB954),
                  modifier = Modifier.size(22.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                  text = stringResource(R.string.spotify_playlists_title),
                  style = MaterialTheme.typography.titleLarge,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onSurface,
                )
              }
              if (spotifyUiState.isAuthenticated) {
                val total = spotifyUiState.playlists.size + 1
                Text(
                  text = pluralStringResource(R.plurals.n_playlist, total, total),
                  style = MaterialTheme.typography.titleSmall,
                  color = MaterialTheme.colorScheme.secondary,
                )
              }
            }
          }

          if (!spotifyUiState.isAuthenticated) {
            item(
              key = "spotify_connect_banner",
              span = { GridItemSpan(maxLineSpan) }
            ) {
              SpotifyConnectBanner(
                onConnect = { navController.navigate("settings/spotify_import") },
                onRefresh = { spotifyViewModel.refresh() }
              )
            }
          } else {
            // Liked songs grid item
            item(key = "spotify_liked_songs") {
              val songCount = spotifyUiState.likedSongsCount ?: 0
              GridItem(
                title = {
                  Text(
                    text = stringResource(R.string.spotify_liked_songs),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                },
                subtitle = {
                  Text(
                    text = pluralStringResource(R.plurals.n_song, songCount, songCount),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                },
                badges = {
                  Icon(
                    painter = painterResource(R.drawable.ic_push_pin),
                    contentDescription = null,
                    tint = Color(0xFF1DB954),
                    modifier = Modifier.size(14.dp).padding(end = 2.dp)
                  )
                },
                thumbnailContent = {
                  Box(
                    modifier = Modifier
                      .fillMaxSize()
                      .clip(RoundedCornerShape(ThumbnailCornerRadius))
                      .background(
                        Brush.linearGradient(
                          listOf(
                            Color(0xFF450AF5),
                            Color(0xFF8E8EE5),
                            Color(0xFFABEDD8),
                          )
                        )
                      ),
                    contentAlignment = Alignment.Center,
                  ) {
                    Icon(
                      painter = painterResource(R.drawable.favorite),
                      contentDescription = null,
                      tint = Color.White,
                      modifier = Modifier.size(32.dp),
                    )
                    AsyncImage(
                      model = SPOTIFY_LIKED_SONGS_COVER,
                      contentDescription = null,
                      contentScale = ContentScale.Crop,
                      modifier = Modifier.fillMaxSize(),
                    )
                  }
                },
                fillMaxWidth = true,
                modifier = Modifier
                  .fillMaxWidth()
                  .clickable {
                    val titleEnc = Uri.encode("Liked Songs")
                    val coverEnc = Uri.encode(SPOTIFY_LIKED_SONGS_COVER)
                    navController.navigate("spotify_playlist/liked?title=$titleEnc&cover=$coverEnc")
                  }
              )
            }

            // Spotify playlists grid items
            items(
              items = spotifyUiState.playlists,
              key = { "spotify_${it.id}" }
            ) { spPlaylist ->
              val coverUrl = SpotifyMapper.getPlaylistThumbnail(spPlaylist)
              val countText = spPlaylist.tracks?.total?.let { "$it songs" } ?: ""

              GridItem(
                title = {
                  Text(
                    text = spPlaylist.name,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                },
                subtitle = {
                  Text(
                    text = countText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                },
                thumbnailContent = {
                  AsyncImage(
                    model = coverUrl,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                      .fillMaxSize()
                      .clip(RoundedCornerShape(ThumbnailCornerRadius))
                      .background(MaterialTheme.colorScheme.surfaceContainerHighest),
                  )
                },
                fillMaxWidth = true,
                modifier = Modifier
                  .fillMaxWidth()
                  .clickable {
                    val titleEnc = Uri.encode(spPlaylist.name)
                    val coverEnc = Uri.encode(coverUrl.orEmpty())
                    navController.navigate("spotify_playlist/${spPlaylist.id}?title=$titleEnc&cover=$coverEnc")
                  }
              )
            }
          }

          if (sortedArtists.isNotEmpty()) {
            item(
              key = "artists_header",
              span = { GridItemSpan(maxLineSpan) },
              contentType = CONTENT_TYPE_HEADER,
            ) {
              androidx.compose.material3.Text(
                text = stringResource(R.string.filter_artists),
                style = androidx.compose.material3.MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp)
              )
            }

            items(
              items = sortedArtists.distinctBy { it.id },
              key = { "artist_${it.id}" },
              contentType = { "artist" },
            ) { item ->
              ArtistGridItem(
                artist = item,
                fillMaxWidth = true,
                modifier =
                  Modifier.fillMaxWidth()
                    .combinedClickable(
                      onClick = { navController.navigate("artist/${item.id}") },
                      onLongClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        menuState.show {
                          ArtistMenu(
                            originalArtist = item,
                            coroutineScope = coroutineScope,
                            onDismiss = menuState::dismiss,
                          )
                        }
                      },
                    )
                    .animateItem(),
              )
            }
          }

          if (sortedAlbums.isNotEmpty()) {
            item(
              key = "albums_header",
              span = { GridItemSpan(maxLineSpan) },
              contentType = CONTENT_TYPE_HEADER,
            ) {
              androidx.compose.material3.Text(
                text = stringResource(R.string.filter_albums),
                style = androidx.compose.material3.MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp)
              )
            }

            items(
              items = sortedAlbums.distinctBy { it.id },
              key = { "album_${it.id}" },
              contentType = { "album" },
            ) { item ->
              AlbumGridItem(
                album = item,
                isActive = item.id == mediaMetadata?.album?.id,
                isPlaying = isPlaying,
                coroutineScope = coroutineScope,
                fillMaxWidth = true,
                modifier =
                  Modifier.fillMaxWidth()
                    .combinedClickable(
                      onClick = { navController.navigate("album/${item.id}") },
                      onLongClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        menuState.show {
                          AlbumMenu(
                            originalAlbum = item,
                            navController = navController,
                            onDismiss = menuState::dismiss,
                          )
                        }
                      },
                    )
                    .animateItem(),
              )
            }
          }
        }
    }
  }
}
