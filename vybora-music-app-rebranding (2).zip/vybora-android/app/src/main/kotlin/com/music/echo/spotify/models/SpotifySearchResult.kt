/*
 * EchoMusic (2026)
 * © Chartreux Westia — github.com/koiverse
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package echo.music.iad1tya.spotify.models

import kotlinx.serialization.Serializable

@Serializable
data class SpotifySearchResult(
  val tracks: SpotifyPaging<SpotifyTrack>? = null,
  val playlists: SpotifyPaging<SpotifyPlaylist>? = null,
  val albums: SpotifyPaging<SpotifyAlbum>? = null,
  val artists: SpotifyPaging<SpotifyArtist>? = null,
)
