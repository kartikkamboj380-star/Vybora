package echo.music.iad1tya.ui.screens.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import echo.music.iad1tya.R
import echo.music.iad1tya.constants.DiscordActivityButton1CustomUrlKey
import echo.music.iad1tya.constants.DiscordActivityButton1EnabledKey
import echo.music.iad1tya.constants.DiscordActivityButton1LabelKey
import echo.music.iad1tya.constants.DiscordActivityButton1UrlSourceKey
import echo.music.iad1tya.constants.DiscordActivityButton2CustomUrlKey
import echo.music.iad1tya.constants.DiscordActivityButton2EnabledKey
import echo.music.iad1tya.constants.DiscordActivityButton2LabelKey
import echo.music.iad1tya.constants.DiscordActivityButton2UrlSourceKey
import echo.music.iad1tya.ui.component.EditTextPreference
import echo.music.iad1tya.ui.component.ListPreference
import echo.music.iad1tya.ui.component.SwitchPreference
import echo.music.iad1tya.utils.rememberPreference

private val DiscordExperimentalButtonUrlOptions =
  listOf("songurl", "artisturl", "albumurl", "custom")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiscordExperimental(navController: NavController) {
  val context = LocalContext.current

  val (button1Label, onButton1LabelChange) =
    rememberPreference(
      key = DiscordActivityButton1LabelKey,
      defaultValue = "Listen on YouTube Music",
    )
  val (button1Enabled, onButton1EnabledChange) =
    rememberPreference(
      key = DiscordActivityButton1EnabledKey,
      defaultValue = true,
    )
  val (button2Label, onButton2LabelChange) =
    rememberPreference(
      key = DiscordActivityButton2LabelKey,
      defaultValue = "Go to VYBORA",
    )
  val (button2Enabled, onButton2EnabledChange) =
    rememberPreference(
      key = DiscordActivityButton2EnabledKey,
      defaultValue = false,
    )

  val (button1UrlSource, onButton1UrlSourceChange) =
    rememberPreference(
      key = DiscordActivityButton1UrlSourceKey,
      defaultValue = "songurl",
    )
  val (button1CustomUrl, onButton1CustomUrlChange) =
    rememberPreference(
      key = DiscordActivityButton1CustomUrlKey,
      defaultValue = "",
    )
  val (button2UrlSource, onButton2UrlSourceChange) =
    rememberPreference(
      key = DiscordActivityButton2UrlSourceKey,
      defaultValue = "custom",
    )
  val (button2CustomUrl, onButton2CustomUrlChange) =
    rememberPreference(
      key = DiscordActivityButton2CustomUrlKey,
      defaultValue = "",
    )

  Scaffold { inner ->
    Column(Modifier.fillMaxSize()) {
      TopAppBar(
        title = { Text(stringResource(R.string.experiment_settings)) },
        navigationIcon = {
          IconButton(onClick = navController::navigateUp) {
            Icon(painterResource(R.drawable.arrow_back), contentDescription = null)
          }
        },
      )

      LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding =
          PaddingValues(
            bottom = inner.calculateBottomPadding() + 80.dp,
          ),
        verticalArrangement = Arrangement.spacedBy(16.dp),
      ) {
        item {
          PreferenceGroup(title = "Discord Button Options") {
            item {
              SwitchPreference(
                title = { Text("Show Button 1") },
                description = "Show Button 1 on Discord RPC",
                icon = { Icon(painterResource(R.drawable.add), null) },
                checked = button1Enabled,
                onCheckedChange = onButton1EnabledChange,
              )
            }

            if (button1Enabled) {
              item {
                EditTextPreference(
                  title = { Text("Button 1 Label") },
                  icon = { Icon(painterResource(R.drawable.edit), null) },
                  value = button1Label,
                  onValueChange = onButton1LabelChange,
                  isInputValid = { true },
                )
              }

              item {
                ListPreference(
                  title = { Text("Button 1 URL Source") },
                  icon = { Icon(painterResource(R.drawable.link), null) },
                  selectedValue = button1UrlSource,
                  values = DiscordExperimentalButtonUrlOptions,
                  valueText = { discordUrlSourceLabel(it) },
                  onValueSelected = onButton1UrlSourceChange,
                )
              }
            }

            if (button1Enabled && button1UrlSource == "custom") {
              item {
                EditTextPreference(
                  title = { Text("Button 1 Custom URL") },
                  icon = { Icon(painterResource(R.drawable.link), null) },
                  value = button1CustomUrl,
                  onValueChange = onButton1CustomUrlChange,
                  isInputValid = { true },
                )
              }
            }
          }
        }

        item {
          PreferenceGroup(title = "Discord Button 2 Options") {
            item {
              SwitchPreference(
                title = { Text("Show Button 2") },
                description = "Show Button 2 on Discord RPC",
                icon = { Icon(painterResource(R.drawable.add), null) },
                checked = button2Enabled,
                onCheckedChange = onButton2EnabledChange,
              )
            }

            if (button2Enabled) {
              item {
                EditTextPreference(
                  title = { Text("Button 2 Label") },
                  icon = { Icon(painterResource(R.drawable.edit), null) },
                  value = button2Label,
                  onValueChange = onButton2LabelChange,
                  isInputValid = { true },
                )
              }

              item {
                ListPreference(
                  title = { Text("Button 2 URL Source") },
                  icon = { Icon(painterResource(R.drawable.link), null) },
                  selectedValue = button2UrlSource,
                  values = DiscordExperimentalButtonUrlOptions,
                  valueText = { discordUrlSourceLabel(it) },
                  onValueSelected = onButton2UrlSourceChange,
                )
              }
            }

            if (button2Enabled && button2UrlSource == "custom") {
              item {
                EditTextPreference(
                  title = { Text("Button 2 Custom URL") },
                  icon = { Icon(painterResource(R.drawable.link), null) },
                  value = button2CustomUrl,
                  onValueChange = onButton2CustomUrlChange,
                  isInputValid = { true },
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun discordUrlSourceLabel(source: String): String =
  when (source) {
    "songurl" -> stringResource(R.string.discord_url_source_song)
    "artisturl" -> stringResource(R.string.discord_url_source_artist)
    "albumurl" -> stringResource(R.string.discord_url_source_album)
    "custom" -> stringResource(R.string.discord_url_source_custom)
    else -> source
  }
