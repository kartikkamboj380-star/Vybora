package echo.music.iad1tya.ui.menu

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.TextUnitType
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import com.music.innertube.YouTube
import com.music.innertube.models.SongItem
import echo.music.iad1tya.LocalDatabase
import echo.music.iad1tya.R
import echo.music.iad1tya.constants.AddToPlaylistSortDescendingKey
import echo.music.iad1tya.constants.AddToPlaylistSortTypeKey
import echo.music.iad1tya.constants.ListThumbnailSize
import echo.music.iad1tya.constants.PlaylistSortType
import echo.music.iad1tya.db.entities.Playlist
import echo.music.iad1tya.db.entities.Song
import echo.music.iad1tya.models.ItemsPage
import echo.music.iad1tya.models.toMediaMetadata
import echo.music.iad1tya.models.toSongEntity
import echo.music.iad1tya.ui.component.CreatePlaylistDialog
import echo.music.iad1tya.ui.component.DefaultDialog
import echo.music.iad1tya.ui.component.ListDialog
import echo.music.iad1tya.ui.component.ListItem
import echo.music.iad1tya.ui.component.PlaylistListItem
import echo.music.iad1tya.ui.component.SortHeader
import echo.music.iad1tya.utils.listItemShape
import echo.music.iad1tya.utils.rememberEnumPreference
import echo.music.iad1tya.utils.rememberPreference
import echo.music.iad1tya.utils.reportException
import echo.music.iad1tya.viewmodels.PlaylistsViewModel
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber

/**
 * Ranks a full collaboration match (every target artist present, and only target artists) above a
 * partial one, and requires exact (not substring) name equality throughout — a `contains` check
 * would let a short or generic target name ("Nas") false-positive against an unrelated artist
 * ("Nasty"), and would let a single-artist partial match win over the correct multi-artist
 * collaboration purely because it happened to come first.
 */
private fun findBestMatchingSong(items: List<SongItem>, targetArtists: List<String>): SongItem? {
  val normalizedTargets =
    targetArtists.map { it.trim().lowercase() }.filter { it.isNotEmpty() }.toSet()
  if (normalizedTargets.isEmpty()) return items.firstOrNull()

  val exactSetMatch =
    items.firstOrNull { item ->
      val itemArtists = item.artists.map { it.name.trim().lowercase() }.toSet()
      itemArtists == normalizedTargets
    }
  if (exactSetMatch != null) return exactSetMatch

  val exactNameMatch =
    items.firstOrNull { item ->
      item.artists.any { artist -> artist.name.trim().lowercase() in normalizedTargets }
    }

  return exactNameMatch ?: items.firstOrNull()
}

@Composable
fun AddToPlaylistDialogOnline(
  isVisible: Boolean,
  allowSyncing: Boolean = true,
  initialTextFieldValue: String? = null,
  songs: SnapshotStateList<Song>,
  onDismiss: () -> Unit,
  onProgressStart: (Boolean) -> Unit,
  onPercentageChange: (Int) -> Unit,
  viewModel: PlaylistsViewModel = hiltViewModel()
) {
  val database = LocalDatabase.current
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val viewStateMap = remember { mutableStateMapOf<String, ItemsPage?>() }
  val (sortType, onSortTypeChange) =
    rememberEnumPreference(AddToPlaylistSortTypeKey, PlaylistSortType.NAME)
  val (sortDescending, onSortDescendingChange) =
    rememberPreference(AddToPlaylistSortDescendingKey, false)
  val playlists by viewModel.allPlaylists.collectAsState()

  var showCreatePlaylistDialog by rememberSaveable { mutableStateOf(false) }

  var showDuplicateDialog by remember { mutableStateOf(false) }
  var selectedPlaylist by remember { mutableStateOf<Playlist?>(null) }
  val songIds by remember { mutableStateOf<List<String>?>(null) }
  val duplicates by remember { mutableStateOf(emptyList<String>()) }
  var searchQuery by rememberSaveable { mutableStateOf("") }
  val filteredPlaylists =
    remember(playlists, searchQuery) {
      if (searchQuery.isBlank()) {
        playlists
      } else {
        playlists.filter { it.playlist.name.contains(searchQuery, ignoreCase = true) }
      }
    }

  if (isVisible) {
    val totalItemsCount = 1 + filteredPlaylists.size
    ListDialog(onDismiss = onDismiss) {
      item {
        ListItem(
          title = stringResource(R.string.create_playlist),
          thumbnailContent = {
            Image(
              painter = painterResource(id = R.drawable.playlist_add),
              contentDescription = null,
              colorFilter = ColorFilter.tint(MaterialTheme.colorScheme.onBackground),
              modifier = Modifier.size(ListThumbnailSize)
            )
          },
          shape = listItemShape(index = 0, count = totalItemsCount),
          modifier = Modifier.clickable { showCreatePlaylistDialog = true }
        )
      }

      if (playlists.isNotEmpty()) {
        item {
          OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = {
              Text(
                text = stringResource(R.string.search),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
              )
            },
            leadingIcon = {
              Icon(
                painter = painterResource(R.drawable.search),
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
              )
            },
            trailingIcon = {
              if (searchQuery.isNotEmpty()) {
                IconButton(onClick = { searchQuery = "" }) {
                  Icon(
                    painter = painterResource(R.drawable.close),
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
              }
            },
            singleLine = true,
            shape = RoundedCornerShape(24.dp),
            colors =
              OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                unfocusedContainerColor =
                  MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                cursorColor = MaterialTheme.colorScheme.primary,
              ),
            textStyle = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
          )
        }
      }

      if (playlists.isNotEmpty()) {
        item {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(start = 16.dp),
          ) {
            SortHeader(
              sortType = sortType,
              sortDescending = sortDescending,
              onSortTypeChange = onSortTypeChange,
              onSortDescendingChange = onSortDescendingChange,
              sortTypeText = { sortType ->
                when (sortType) {
                  PlaylistSortType.CREATE_DATE -> R.string.sort_by_create_date
                  PlaylistSortType.NAME -> R.string.sort_by_name
                  PlaylistSortType.SONG_COUNT -> R.string.sort_by_song_count
                  PlaylistSortType.LAST_UPDATED -> R.string.sort_by_last_updated
                }
              },
            )
          }
        }
      }

      if (filteredPlaylists.isEmpty() && searchQuery.isNotEmpty()) {
        item {
          Text(
            text = stringResource(R.string.no_results_found),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
            textAlign = TextAlign.Center
          )
        }
      }

      itemsIndexed(filteredPlaylists) { index, playlist ->
        PlaylistListItem(
          playlist = playlist,
          shape = listItemShape(index = index + 1, count = totalItemsCount),
          modifier =
            Modifier.clickable {
              selectedPlaylist = playlist
              coroutineScope.launch(Dispatchers.IO) {
                onDismiss()
                val songsTot = songs.count().toDouble()
                var songsIdx = 0.toDouble()
                onProgressStart(true)
                songs.reversed().forEach { song ->
                  val targetArtistNames =
                    song.artists.map { artist ->
                      URLDecoder.decode(artist.name, StandardCharsets.UTF_8.toString())
                    }
                  val allArtists = targetArtistNames.joinToString("") { " $it" }
                  val query = "${song.title} - $allArtists"

                  coroutineScope.launch {
                    try {
                      YouTube.search(query, YouTube.SearchFilter.FILTER_SONG)
                        .onSuccess { result ->
                          val items = result.items.distinctBy { it.id }
                          if (items.isNotEmpty()) {
                            viewStateMap[YouTube.SearchFilter.FILTER_SONG.value] =
                              ItemsPage(items, result.continuation)
                            val itemsPage = viewStateMap.entries.firstOrNull()?.value
                            val songItems =
                              itemsPage?.items?.filterIsInstance<SongItem>() ?: emptyList()
                            val firstSong = findBestMatchingSong(songItems, targetArtistNames)
                            if (firstSong != null) {
                              val firstSongMedia = firstSong.toMediaMetadata()
                              val ids = listOf(firstSong.id)
                              withContext(Dispatchers.IO) {
                                try {
                                  database.insert(firstSongMedia)
                                } catch (e: Exception) {
                                  Timber.tag("Exception inserting song in database:")
                                    .e(e.toString())
                                }
                                database.addSongToPlaylist(playlist, ids)
                              }
                            }
                            viewStateMap.clear()
                          }
                          songsIdx += 1
                        }
                        .onFailure {
                          reportException(it)
                          songsIdx += 1
                        }

                      if (songsIdx.toInt() == songsTot.toInt() - 1) {
                        onProgressStart(false)
                        withContext(Dispatchers.Main) {
                          Toast.makeText(
                              context,
                              context.getString(R.string.added_to_playlist, playlist.playlist.name),
                              Toast.LENGTH_SHORT
                            )
                            .show()
                        }
                      }
                      onPercentageChange(((songsIdx / songsTot) * 100).toInt())
                    } catch (e: Exception) {
                      Timber.tag("ERROR").v(e.toString())
                    }
                  }
                }
              }
            }
        )
      }

      item {
        ListItem(
          modifier =
            Modifier.clickable {
              coroutineScope.launch(Dispatchers.IO) {
                onDismiss()
                val songsTot = songs.count().toDouble()
                var songsIdx = 0.toDouble()
                onProgressStart(true)
                songs.reversed().forEach { song ->
                  val targetArtistNames =
                    song.artists.map { artist ->
                      URLDecoder.decode(artist.name, StandardCharsets.UTF_8.toString())
                    }
                  val allArtists = targetArtistNames.joinToString("") { " $it" }
                  val query = "${song.title} - $allArtists"

                  coroutineScope.launch {
                    try {
                      YouTube.search(query, YouTube.SearchFilter.FILTER_SONG)
                        .onSuccess { result ->
                          val items = result.items.distinctBy { it.id }
                          if (items.isNotEmpty()) {
                            viewStateMap[YouTube.SearchFilter.FILTER_SONG.value] =
                              ItemsPage(items, result.continuation)
                            val itemsPage = viewStateMap.entries.firstOrNull()?.value
                            val songItems =
                              itemsPage?.items?.filterIsInstance<SongItem>() ?: emptyList()
                            val firstSong = findBestMatchingSong(songItems, targetArtistNames)
                            if (firstSong != null) {
                              val firstSongMedia = firstSong.toMediaMetadata()
                              val firstSongEnt = firstSong.toMediaMetadata().toSongEntity()
                              withContext(Dispatchers.IO) {
                                try {
                                  database.insert(firstSongMedia)
                                  database.query { update(firstSongEnt.toggleLike()) }
                                } catch (e: Exception) {
                                  Timber.tag("Exception inserting song in database:")
                                    .e(e.toString())
                                }
                              }
                            }
                            viewStateMap.clear()
                          }
                          songsIdx += 1
                        }
                        .onFailure {
                          reportException(it)
                          songsIdx += 1
                        }

                      if (songsIdx.toInt() == songsTot.toInt() - 1) {
                        onProgressStart(false)
                        withContext(Dispatchers.Main) {
                          Toast.makeText(
                              context,
                              context.getString(
                                R.string.added_to_playlist,
                                context.getString(R.string.liked_songs)
                              ),
                              Toast.LENGTH_SHORT
                            )
                            .show()
                        }
                      }
                      onPercentageChange(((songsIdx / songsTot) * 100).toInt())
                    } catch (e: Exception) {
                      Timber.tag("ERROR").v(e.toString())
                    }
                  }
                }
              }
            },
          title = stringResource(R.string.liked_songs),
          thumbnailContent = {
            Image(
              painter = painterResource(id = R.drawable.favorite),
              contentDescription = null,
              modifier = Modifier.size(40.dp),
              colorFilter = ColorFilter.tint(MaterialTheme.colorScheme.onBackground)
            )
          },
          trailingContent = {}
        )
      }

      item {
        Text(
          text = stringResource(R.string.playlist_add_local_to_synced_note),
          fontSize = TextUnit(12F, TextUnitType.Sp),
          modifier = Modifier.padding(horizontal = 20.dp)
        )
      }
    }
  }

  if (showCreatePlaylistDialog) {
    CreatePlaylistDialog(
      onDismiss = { showCreatePlaylistDialog = false },
      initialTextFieldValue = initialTextFieldValue,
      allowSyncing = allowSyncing
    )
  }

  if (showDuplicateDialog) {
    DefaultDialog(
      title = { Text(stringResource(R.string.duplicates)) },
      buttons = {
        TextButton(
          onClick = {
            showDuplicateDialog = false
            onDismiss()
            database.transaction {
              addSongToPlaylist(selectedPlaylist!!, songIds!!.filter { !duplicates.contains(it) })
            }
            Toast.makeText(
                context,
                context.getString(R.string.added_to_playlist, selectedPlaylist!!.playlist.name),
                Toast.LENGTH_SHORT
              )
              .show()
          }
        ) {
          Text(stringResource(R.string.skip_duplicates))
        }

        TextButton(
          onClick = {
            showDuplicateDialog = false
            onDismiss()
            database.transaction { addSongToPlaylist(selectedPlaylist!!, songIds!!) }
            Toast.makeText(
                context,
                context.getString(R.string.added_to_playlist, selectedPlaylist!!.playlist.name),
                Toast.LENGTH_SHORT
              )
              .show()
          }
        ) {
          Text(stringResource(R.string.add_anyway))
        }

        TextButton(onClick = { showDuplicateDialog = false }) {
          Text(stringResource(android.R.string.cancel))
        }
      },
      onDismiss = { showDuplicateDialog = false }
    ) {
      Text(
        text =
          if (duplicates.size == 1) {
            stringResource(R.string.duplicates_description_single)
          } else {
            stringResource(R.string.duplicates_description_multiple, duplicates.size)
          },
        textAlign = TextAlign.Start,
        modifier = Modifier.align(Alignment.Start)
      )
    }
  }
}
