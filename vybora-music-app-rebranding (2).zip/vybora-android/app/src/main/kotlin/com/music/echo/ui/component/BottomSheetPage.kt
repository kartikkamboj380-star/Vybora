package echo.music.iad1tya.ui.component

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.unit.dp

val LocalBottomSheetPageState = compositionLocalOf { BottomSheetPageState() }

@Stable
class BottomSheetPageState(
  isVisible: Boolean = false,
  content: @Composable ColumnScope.() -> Unit = {},
) {
  var isVisible by mutableStateOf(isVisible)
  var content by mutableStateOf(content)

  fun show(content: @Composable ColumnScope.() -> Unit) {
    isVisible = true
    this.content = content
  }

  fun dismiss() {
    isVisible = false
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BottomSheetPage(
  modifier: Modifier = Modifier,
  state: BottomSheetPageState,
  background: Color = MaterialTheme.colorScheme.surfaceContainer,
) {
  val focusManager = LocalFocusManager.current
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false)

  AnimatedBottomSheet(
    isVisible = state.isVisible,
    onDismissRequest = {
      focusManager.clearFocus()
      state.isVisible = false
    },
    sheetState = sheetState,
    containerColor = background,
    contentColor = MaterialTheme.colorScheme.onSurface,
    dragHandle = {
      Box(
        modifier =
          Modifier.padding(vertical = 12.dp)
            .size(width = 32.dp, height = 4.dp)
            .clip(RoundedCornerShape(2.dp))
            .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
      )
    },
    modifier = modifier.fillMaxHeight()
  ) {
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 16.dp)) {
      state.content(this)
    }
  }
}
