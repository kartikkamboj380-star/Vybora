package echo.music.iad1tya.ui.screens.playlist

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ButtonGroupDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ContainedLoadingIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.ToggleButton
import androidx.compose.material3.ToggleButtonDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarScrollBehavior
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshotFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.fastAny
import androidx.compose.ui.util.fastForEachReversed
import androidx.core.net.toUri
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadRequest
import androidx.media3.exoplayer.offline.DownloadService
import androidx.navigation.NavController
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import com.music.innertube.models.AlbumItem
import com.music.innertube.models.ArtistItem
import com.music.innertube.models.PlaylistItem
import com.music.innertube.models.SongItem
import com.music.innertube.models.WatchEndpoint
import echo.music.iad1tya.LocalDatabase
import echo.music.iad1tya.LocalDownloadUtil
import echo.music.iad1tya.LocalPlayerAwareWindowInsets
import echo.music.iad1tya.LocalPlayerConnection
import echo.music.iad1tya.R
import echo.music.iad1tya.constants.AppBarHeight
import echo.music.iad1tya.constants.HideExplicitKey
import echo.music.iad1tya.constants.PodcastHidePlayedKey
import echo.music.iad1tya.db.entities.Playlist
import echo.music.iad1tya.db.entities.PlaylistEntity
import echo.music.iad1tya.db.entities.PlaylistSongMap
import echo.music.iad1tya.models.toMediaMetadata
import echo.music.iad1tya.playback.DownloadUtil
import echo.music.iad1tya.playback.ExoDownloadService
import echo.music.iad1tya.playback.queues.YouTubePlaylistQueue
import echo.music.iad1tya.playback.queues.YouTubeQueue
import echo.music.iad1tya.ui.component.ChipsRow
import echo.music.iad1tya.ui.component.EpisodeDetails
import echo.music.iad1tya.ui.component.HeartBurstIcon
import echo.music.iad1tya.ui.component.IconButton
import echo.music.iad1tya.ui.component.LocalMenuState
import echo.music.iad1tya.ui.component.NavigationTitle
import echo.music.iad1tya.ui.component.OnlineBlur
import echo.music.iad1tya.ui.component.YouTubeGridItem
import echo.music.iad1tya.ui.component.YouTubeListItem
import echo.music.iad1tya.ui.menu.YouTubeAlbumMenu
import echo.music.iad1tya.ui.menu.YouTubeArtistMenu
import echo.music.iad1tya.ui.menu.YouTubePlaylistMenu
import echo.music.iad1tya.ui.menu.YouTubeSelectionSongMenu
import echo.music.iad1tya.ui.menu.YouTubeSongMenu
import echo.music.iad1tya.ui.utils.backToMain
import echo.music.iad1tya.utils.PodcastProgress
import echo.music.iad1tya.utils.listItemShape
import echo.music.iad1tya.utils.rememberPreference
import echo.music.iad1tya.viewmodels.OnlinePlaylistViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@OptIn(
  ExperimentalMaterial3Api::class,
  ExperimentalFoundationApi::class,
  ExperimentalMaterial3ExpressiveApi::class
)
@Composable
fun OnlinePlaylistScreen(
  navController: NavController,
  scrollBehavior: TopAppBarScrollBehavior,
  viewModel: OnlinePlaylistViewModel = hiltViewModel(),
) {
  val menuState = LocalMenuState.current
  val database = LocalDatabase.current
  val downloadUtil = LocalDownloadUtil.current
  val haptic = LocalHapticFeedback.current
  val playerConnection = LocalPlayerConnection.current ?: return
  val coroutineScope = rememberCoroutineScope()

  val isPlaying by playerConnection.isEffectivelyPlaying.collectAsState()
  val mediaMetadata by playerConnection.mediaMetadata.collectAsState()

  val playlist by viewModel.playlist.collectAsState()
  val songs by viewModel.playlistSongs.collectAsState()
  val dbPlaylist by viewModel.dbPlaylist.collectAsState()
  val relatedItems by viewModel.relatedItems.collectAsState()
  val isLoading by viewModel.isLoading.collectAsState()
  val isLoadingMore by viewModel.isLoadingMore.collectAsState()
  val error by viewModel.error.collectAsState()

  val hideExplicit by rememberPreference(key = HideExplicitKey, defaultValue = false)

  val lazyListState = rememberLazyListState()
  val snackbarHostState = remember { SnackbarHostState() }

  var isSearching by rememberSaveable { mutableStateOf(false) }
  // Podcast shows list the newest episode first; oldest first needs every episode loaded.
  var oldestFirst by rememberSaveable { mutableStateOf(false) }
  val isPlaylistLoaded = playlist != null
  LaunchedEffect(oldestFirst, isPlaylistLoaded) {
    if (oldestFirst && isPlaylistLoaded) viewModel.loadAllSongs()
  }
  val (hidePlayed, onHidePlayedChange) = rememberPreference(PodcastHidePlayedKey, false)
  val episodeProgress by PodcastProgress.entries.collectAsState()

  // Beyond the songs loaded up front, load the next page when the list is
  // scrolled close to its end instead of fetching the whole playlist.
  // Search covers the whole playlist, not only the pages loaded so far.
  LaunchedEffect(lazyListState, isSearching) {
    if (isSearching) {
      viewModel.loadAllSongs()
      return@LaunchedEffect
    }
    snapshotFlow {
      val info = lazyListState.layoutInfo
      val lastVisible = info.visibleItemsInfo.lastOrNull()?.index ?: 0
      // The song count is part of the key so a page that still leaves the list
      // short triggers the next one. The total item count is not: it changes
      // with the loading row, so a failed page would be requested again and again.
      (info.totalItemsCount > 0 && lastVisible >= info.totalItemsCount - LOAD_MORE_THRESHOLD) to
        songs.size
    }
      .distinctUntilChanged()
      .collect { (nearEnd, _) -> if (nearEnd) viewModel.loadMoreSongs() }
  }
  var query by
    rememberSaveable(stateSaver = TextFieldValue.Saver) { mutableStateOf(TextFieldValue()) }
  val context = LocalContext.current

  var downloadState by remember { mutableIntStateOf(Download.STATE_STOPPED) }

  LaunchedEffect(songs) {
    if (songs.isNullOrEmpty()) {
      downloadState = Download.STATE_STOPPED
      return@LaunchedEffect
    }
    downloadUtil.downloads.collect { downloads ->
      downloadState = DownloadUtil.computeDownloadState(songs.map { it.id }, downloads)
    }
  }

  val filteredSongs =
    remember(songs, query, oldestFirst, hidePlayed, episodeProgress, playlist) {
      val listed =
        if (hidePlayed && playlist?.isPodcast == true) {
          songs.filterNot { episodeProgress[it.id]?.finished == true }
        } else {
          songs
        }
      val ordered = if (oldestFirst) listed.asReversed() else listed
      if (query.text.isEmpty()) ordered.mapIndexed { i, s -> i to s }
      else
        ordered
          .mapIndexed { i, s -> i to s }
          .filter {
            it.second.title.contains(query.text, true) ||
              it.second.artists.fastAny { a -> a.name.contains(query.text, true) }
          }
    }

  var inSelectMode by rememberSaveable { mutableStateOf(false) }
  val selection =
    rememberSaveable(
      saver =
        listSaver<MutableList<String>, String>(
          save = { it.toList() },
          restore = { it.toMutableStateList() }
        )
    ) {
      mutableStateListOf()
    }
  val onExitSelectionMode = {
    inSelectMode = false
    selection.clear()
  }

  val focusRequester = remember { FocusRequester() }
  LaunchedEffect(isSearching) { if (isSearching) focusRequester.requestFocus() }

  LaunchedEffect(filteredSongs) {
    selection.fastForEachReversed { songId ->
      if (filteredSongs.find { it.second.id == songId } == null) {
        selection.remove(songId)
      }
    }
  }

  val transparentAppBar by remember {
    derivedStateOf {
      lazyListState.firstVisibleItemIndex == 0 && lazyListState.firstVisibleItemScrollOffset < 150
    }
  }

  if (isSearching) {
    BackHandler {
      isSearching = false
      query = TextFieldValue()
    }
  } else if (inSelectMode) {
    BackHandler(onBack = onExitSelectionMode)
  }

  Box(Modifier.fillMaxSize()) {
    LazyColumn(
      state = lazyListState,
      contentPadding =
        LocalPlayerAwareWindowInsets.current.union(WindowInsets.ime).asPaddingValues(),
    ) {
      if (playlist == null || songs.isEmpty()) {
        if (isLoading) {
          item(key = "loading_placeholder") {
            Box(
              modifier = Modifier.fillMaxWidth().padding(32.dp),
              contentAlignment = Alignment.Center
            ) {
              ContainedLoadingIndicator()
            }
          }
        }
      } else {
        playlist?.let { playlist ->
          if (!isSearching) {
            item(key = "playlist_header") {
              OnlinePlaylistHeader(
                playlist = playlist,
                songs = songs,
                dbPlaylist = dbPlaylist,
                downloadState = downloadState,
                navController = navController,
                coroutineScope = coroutineScope,
                continuation = viewModel.continuation,
                loadAllSongs = viewModel::loadAllSongs,
                listedSongs = filteredSongs.map { it.second },
                oldestFirst = oldestFirst,
              )
            }
            if (playlist.isPodcast) {
              item(key = "podcast_order") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  ChipsRow(
                    chips =
                      listOf(
                        false to stringResource(R.string.sort_newest),
                        true to stringResource(R.string.sort_oldest),
                      ),
                    currentValue = oldestFirst,
                    onValueUpdate = { oldestFirst = it },
                    modifier = Modifier.weight(1f),
                  )
                  FilterChip(
                    selected = hidePlayed,
                    onClick = { onHidePlayedChange(!hidePlayed) },
                    label = { Text(stringResource(R.string.hide_played)) },
                    modifier = Modifier.padding(end = 12.dp),
                  )
                }
              }
            }
          }

          itemsIndexed(filteredSongs) { index, (_, songItem) ->
            val onCheckedChange: (Boolean) -> Unit = {
              if (it) {
                selection.add(songItem.id)
              } else {
                selection.remove(songItem.id)
              }
            }

            YouTubeListItem(
              item = songItem,
              isActive = mediaMetadata?.id == songItem.id,
              isPlaying = isPlaying,
              isSelected = inSelectMode && songItem.id in selection,
              shape = listItemShape(index, filteredSongs.size),
              modifier =
                Modifier.combinedClickable(
                    enabled = !hideExplicit || !songItem.explicit,
                    onClick = {
                      if (inSelectMode) {
                        onCheckedChange(songItem.id !in selection)
                      } else if (songItem.id == mediaMetadata?.id) {
                        playerConnection.togglePlayPause()
                      } else {
                        // What follows an episode is the next one out, so a show queues
                        // forward in time however the list is sorted. Further pages are
                        // older episodes, which do not follow on then.
                        val newestFirst = playlist.isPodcast && !oldestFirst
                        val listed = filteredSongs.map { it.second }
                        playerConnection.playQueue(
                          YouTubePlaylistQueue(
                            playlistId = playlist.id,
                            playlistTitle = playlist.title,
                            initialSongs = if (newestFirst) listed.asReversed() else listed,
                            initialContinuation =
                              if (oldestFirst || playlist.isPodcast) null
                              else viewModel.continuation,
                            startIndex = if (newestFirst) listed.lastIndex - index else index
                          )
                        )
                      }
                    },
                    onLongClick = {
                      if (!inSelectMode) {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        inSelectMode = true
                        onCheckedChange(true)
                      }
                    }
                  )
                  .animateItem(),
              trailingContent = {
                if (inSelectMode) {
                  Checkbox(checked = songItem.id in selection, onCheckedChange = onCheckedChange)
                } else {
                  if (songItem.isPodcastEpisode && songItem.description != null) {
                    IconButton(
                      onClick = { menuState.show { EpisodeDetails(songItem, menuState::dismiss) } }
                    ) {
                      Icon(
                        painterResource(R.drawable.info),
                        stringResource(R.string.episode_details),
                      )
                    }
                  }
                  IconButton(
                    onClick = {
                      menuState.show {
                        YouTubeSongMenu(songItem, navController, menuState::dismiss)
                      }
                    }
                  ) {
                    Icon(painterResource(R.drawable.more_vert), null)
                  }
                }
              }
            )
          }

          if (isLoadingMore) {
            item(key = "loading_more") {
              Box(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                contentAlignment = Alignment.Center
              ) {
                ContainedLoadingIndicator()
              }
            }
          }

          if (relatedItems.isNotEmpty() && !isSearching) {
            item(key = "related_title") {
              NavigationTitle(
                title = stringResource(R.string.you_might_also_like),
                modifier = Modifier.animateItem()
              )
            }

            item(key = "related_items") {
              LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth().animateItem()
              ) {
                items(relatedItems) { item ->
                  YouTubeGridItem(
                    item = item,
                    modifier =
                      Modifier.width(160.dp)
                        .combinedClickable(
                          onClick = {
                            when (item) {
                              is PlaylistItem ->
                                navController.navigate("online_playlist/${item.id}")
                              is AlbumItem -> navController.navigate("album/${item.browseId}")
                              is ArtistItem -> navController.navigate("artist/${item.id}")
                              is SongItem ->
                                playerConnection.playQueue(
                                  YouTubeQueue(WatchEndpoint(videoId = item.id))
                                )
                            }
                          },
                          onLongClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            menuState.show {
                              when (item) {
                                is PlaylistItem ->
                                  YouTubePlaylistMenu(
                                    playlist = item,
                                    coroutineScope = coroutineScope,
                                    onDismiss = menuState::dismiss
                                  )
                                is SongItem ->
                                  YouTubeSongMenu(
                                    song = item,
                                    navController = navController,
                                    onDismiss = menuState::dismiss
                                  )
                                is AlbumItem ->
                                  YouTubeAlbumMenu(
                                    albumItem = item,
                                    navController = navController,
                                    onDismiss = menuState::dismiss
                                  )
                                is ArtistItem ->
                                  YouTubeArtistMenu(artist = item, onDismiss = menuState::dismiss)
                              }
                            }
                          }
                        )
                  )
                }
              }
            }
          }

          item(key = "bottom_spacer") { Spacer(Modifier.height(50.dp)) }
        }
      }
    }

    TopAppBar(
      title = {
        if (inSelectMode) {
          Text(
            text = pluralStringResource(R.plurals.n_song, selection.size, selection.size),
            style = MaterialTheme.typography.titleLarge
          )
        } else if (isSearching) {
          TextField(
            value = query,
            onValueChange = { query = it },
            placeholder = {
              Text(
                text = stringResource(R.string.search),
                style = MaterialTheme.typography.titleLarge
              )
            },
            singleLine = true,
            textStyle = MaterialTheme.typography.titleLarge,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            colors =
              TextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                disabledIndicatorColor = Color.Transparent,
              ),
            modifier = Modifier.fillMaxWidth().focusRequester(focusRequester)
          )
        } else {
          AnimatedContent(
            targetState = !transparentAppBar,
            transitionSpec = { fadeIn().togetherWith(fadeOut()) },
            label = "TopAppBarTitle"
          ) { show ->
            if (show) {
              Text(playlist?.title ?: "")
            }
          }
        }
      },
      navigationIcon = {
        IconButton(
          modifier =
            Modifier.background(
              androidx.compose.material3.MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
              CircleShape
            ),
          onClick = {
            if (isSearching) {
              isSearching = false
              query = TextFieldValue()
            } else if (inSelectMode) {
              onExitSelectionMode()
            } else {
              navController.navigateUp()
            }
          },
          onLongClick = {
            if (!isSearching && !inSelectMode) {
              navController.backToMain()
            }
          }
        ) {
          Icon(
            painter =
              painterResource(if (inSelectMode) R.drawable.close else R.drawable.arrow_back),
            contentDescription = null
          )
        }
      },
      actions = {
        if (inSelectMode) {
          Checkbox(
            checked = selection.size == filteredSongs.size && selection.isNotEmpty(),
            onCheckedChange = {
              if (selection.size == filteredSongs.size) {
                selection.clear()
              } else {
                selection.clear()
                selection.addAll(filteredSongs.map { it.second.id })
              }
            }
          )
          IconButton(
            enabled = selection.isNotEmpty(),
            onClick = {
              menuState.show {
                YouTubeSelectionSongMenu(
                  songSelection =
                    filteredSongs.filter { it.second.id in selection }.map { it.second },
                  onDismiss = menuState::dismiss,
                  clearAction = onExitSelectionMode
                )
              }
            }
          ) {
            Icon(painter = painterResource(R.drawable.more_vert), contentDescription = null)
          }
        } else if (!isSearching) {
          IconButton(
            onClick = { isSearching = true },
            modifier =
              Modifier.background(
                androidx.compose.material3.MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                CircleShape
              )
          ) {
            Icon(painter = painterResource(R.drawable.search), contentDescription = null)
          }
        }
      },
      colors =
        if (transparentAppBar && !isSearching && !inSelectMode) {
          androidx.compose.material3.TopAppBarDefaults.topAppBarColors(
            containerColor = Color.Transparent
          )
        } else {
          androidx.compose.material3.TopAppBarDefaults.topAppBarColors()
        }
    )

    SnackbarHost(hostState = snackbarHostState, modifier = Modifier.align(Alignment.BottomCenter))
  }
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun OnlinePlaylistHeader(
  playlist: PlaylistItem,
  songs: List<SongItem>,
  dbPlaylist: Playlist?,
  downloadState: Int,
  navController: NavController,
  coroutineScope: CoroutineScope,
  continuation: String?,
  loadAllSongs: suspend () -> List<SongItem>,
  listedSongs: List<SongItem>,
  oldestFirst: Boolean,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val playerConnection = LocalPlayerConnection.current ?: return
  val database = LocalDatabase.current
  val downloadUtil = LocalDownloadUtil.current
  val menuState = LocalMenuState.current
  val isPlaying by playerConnection.isEffectivelyPlaying.collectAsState()
  val mediaMetadata by playerConnection.mediaMetadata.collectAsState()

  val hasExplicitContent = remember(songs) { songs.any { it.explicit } }

  val density = LocalDensity.current
  val systemBarsTopPadding = WindowInsets.systemBars.asPaddingValues().calculateTopPadding()
  val headerOffset = with(density) { -(systemBarsTopPadding + AppBarHeight).roundToPx() }

  Box(modifier = modifier.fillMaxWidth()) {
    OnlineBlur(
      thumbnailUrl = playlist.thumbnail,
      modifier = Modifier.matchParentSize().offset { IntOffset(0, headerOffset) }
    )

    Column(
      modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Spacer(Modifier.height(20.dp))

      Box(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 48.dp),
        contentAlignment = Alignment.Center
      ) {
        AsyncImage(
          model = ImageRequest.Builder(LocalContext.current).data(playlist.thumbnail).build(),
          contentDescription = null,
          modifier =
            Modifier.then(
                if (LocalConfiguration.current.screenWidthDp > 600) Modifier.size(300.dp)
                else Modifier.fillMaxWidth().aspectRatio(1f)
              )
              .clip(RoundedCornerShape(8.dp)),
          contentScale = ContentScale.Crop
        )
      }

      Spacer(Modifier.height(32.dp))

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
        modifier = Modifier.padding(horizontal = 32.dp)
      ) {
        Text(
          text = playlist.title,
          style = MaterialTheme.typography.headlineMedium,
          fontWeight = FontWeight.Bold,
          textAlign = TextAlign.Center,
          color = MaterialTheme.colorScheme.onSurface
        )
      }

      Spacer(Modifier.height(8.dp))

      playlist.author?.name?.let { authorName ->
        Text(
          text = authorName,
          style = MaterialTheme.typography.bodyMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.primary,
          textAlign = TextAlign.Center,
          modifier = Modifier.padding(horizontal = 32.dp)
        )
      }

      Spacer(Modifier.height(16.dp))

      if (hasExplicitContent) {
        Surface(
          shape = RoundedCornerShape(6.dp),
          color = MaterialTheme.colorScheme.surfaceVariant
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
          ) {
            Icon(
              painter = painterResource(R.drawable.explicit),
              contentDescription = "Explicit",
              tint = MaterialTheme.colorScheme.onPrimaryContainer,
              modifier = Modifier.size(14.dp)
            )
            Text(
              text = stringResource(R.string.explicit),
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onPrimaryContainer
            )
          }
        }
        Spacer(Modifier.height(16.dp))
      }

      val totalDuration = songs.sumOf { it.duration ?: 0 }
      Surface(
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.padding(horizontal = 32.dp)
      ) {
        Text(
          text =
            buildString {
              append(
                pluralStringResource(
                  if (playlist.isPodcast) R.plurals.n_episode else R.plurals.n_song,
                  songs.size,
                  songs.size,
                )
              )
              if (totalDuration > 0) {
                append(" • ")
                val hours = totalDuration / 3600
                val minutes = (totalDuration % 3600) / 60
                if (hours > 0) {
                  append("${hours}h ${minutes}m")
                } else {
                  append("${minutes}m")
                }
              }
            },
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
      }

      Spacer(Modifier.height(24.dp))

      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Button(
          onClick = {
            coroutineScope.launch(Dispatchers.IO) {
              if (dbPlaylist != null) {
                database.withTransaction {
                  val currentPlaylist = dbPlaylist.playlist
                  update(currentPlaylist, playlist)
                  update(currentPlaylist.toggleLike())
                }
              } else if (playlist.isPodcast) {
                // Following a show keeps only the show; episodes are loaded when opened.
                database.withTransaction {
                  insert(
                    PlaylistEntity(
                        name = playlist.title,
                        browseId = playlist.id,
                        thumbnailUrl = playlist.thumbnail,
                        isEditable = false,
                      )
                      .toggleLike()
                  )
                }
              } else {
                // Save every song, not only the pages loaded so far.
                val allSongs = loadAllSongs()
                database.withTransaction {
                  val playlistEntity =
                    PlaylistEntity(
                        name = playlist.title,
                        browseId = playlist.id,
                        thumbnailUrl = playlist.thumbnail,
                        isEditable = playlist.isEditable,
                        remoteSongCount =
                          playlist.songCountText?.let {
                            Regex("""\d+""").find(it)?.value?.toIntOrNull()
                          },
                        playEndpointParams = playlist.playEndpoint?.params,
                        shuffleEndpointParams = playlist.shuffleEndpoint?.params,
                        radioEndpointParams = playlist.radioEndpoint?.params
                      )
                      .toggleLike()
                  insert(playlistEntity)
                  allSongs
                    .map { it.toMediaMetadata() }
                    .onEach { insert(it) }
                    .mapIndexed { index, song ->
                      PlaylistSongMap(
                        songId = song.id,
                        playlistId = playlistEntity.id,
                        position = index,
                        setVideoId = song.setVideoId
                      )
                    }
                    .forEach { insert(it) }
                }
              }
            }
          },
          shape = ButtonDefaults.shape,
          colors =
            ButtonDefaults.buttonColors(
              containerColor = MaterialTheme.colorScheme.surfaceVariant,
              contentColor = MaterialTheme.colorScheme.onSurfaceVariant
            ),
          contentPadding = PaddingValues(vertical = 12.dp),
          modifier = Modifier.weight(1f)
        ) {
          Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
          ) {
            HeartBurstIcon(isLiked = dbPlaylist?.playlist?.bookmarkedAt != null, iconSize = 18.dp)
            Text(
              text =
                when {
                  playlist.isPodcast && dbPlaylist?.playlist?.bookmarkedAt != null ->
                    stringResource(R.string.following)
                  playlist.isPodcast -> stringResource(R.string.follow)
                  dbPlaylist?.playlist?.bookmarkedAt != null -> stringResource(R.string.saved)
                  else -> stringResource(R.string.save)
                },
              style = MaterialTheme.typography.labelLarge
            )
          }
        }

        Button(
          onClick = {
            if (playlist.isPodcast) {
              // The list's first episode, then forward in time like tapping an episode.
              if (listedSongs.isNotEmpty()) {
                playerConnection.playQueue(
                  YouTubePlaylistQueue(
                    playlistId = playlist.id,
                    playlistTitle = playlist.title,
                    initialSongs = if (oldestFirst) listedSongs else listedSongs.asReversed(),
                    startIndex = if (oldestFirst) 0 else listedSongs.lastIndex,
                  )
                )
              }
            } else if (songs.isNotEmpty()) {
              playerConnection.playQueue(
                YouTubePlaylistQueue(
                  playlistId = playlist.id,
                  playlistTitle = playlist.title,
                  initialSongs = songs,
                  initialContinuation = continuation
                )
              )
            }
          },
          shape = ButtonDefaults.shape,
          colors =
            ButtonDefaults.buttonColors(
              containerColor = MaterialTheme.colorScheme.primary,
              contentColor = MaterialTheme.colorScheme.onPrimary
            ),
          contentPadding = PaddingValues(vertical = 12.dp),
          modifier = Modifier.weight(1f)
        ) {
          Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              painter =
                painterResource(
                  if (isPlaying && mediaMetadata?.album?.id == playlist.id) R.drawable.pause
                  else R.drawable.play
                ),
              contentDescription = null,
              modifier = Modifier.size(20.dp),
              tint = MaterialTheme.colorScheme.onPrimary
            )
            Spacer(Modifier.width(8.dp))
            Text(
              text =
                if (isPlaying && mediaMetadata?.album?.id == playlist.id)
                  stringResource(R.string.pause)
                else stringResource(R.string.play),
              style = MaterialTheme.typography.labelLarge
            )
          }
        }

        Surface(
          onClick = {
            val intent =
              Intent().apply {
                action = Intent.ACTION_SEND
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, playlist.shareLink)
              }
            context.startActivity(Intent.createChooser(intent, null))
          },
          shape = CircleShape,
          color = MaterialTheme.colorScheme.surfaceVariant,
          modifier = Modifier.size(48.dp)
        ) {
          Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
            Icon(
              painter = painterResource(R.drawable.share),
              contentDescription = stringResource(R.string.share),
              modifier = Modifier.size(20.dp),
              tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }

      Spacer(Modifier.height(16.dp))

      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp),
        horizontalArrangement = Arrangement.spacedBy(ButtonGroupDefaults.ConnectedSpaceBetween),
      ) {
        ToggleButton(
          checked =
            downloadState == Download.STATE_COMPLETED ||
              downloadState == Download.STATE_DOWNLOADING,
          onCheckedChange = {
            coroutineScope.launch {
              // Cover every song, not only the pages loaded so far.
              val allSongs = loadAllSongs()
              val downloads = downloadUtil.downloads.value
              val missingSongs =
                allSongs.filter { song -> !DownloadUtil.hasDownload(song.id, downloads) }
              if (missingSongs.isNotEmpty()) {
                missingSongs.forEach { song ->
                  val downloadRequest =
                    DownloadRequest.Builder(song.id, song.id.toUri())
                      .setCustomCacheKey(song.id)
                      .setData(song.title.toByteArray())
                      .build()
                  DownloadService.sendAddDownload(
                    context,
                    ExoDownloadService::class.java,
                    downloadRequest,
                    false,
                  )
                }
              } else {
                allSongs.forEach { song ->
                  DownloadService.sendRemoveDownload(
                    context,
                    ExoDownloadService::class.java,
                    song.id,
                    false,
                  )
                }
              }
            }
          },
          modifier = Modifier.weight(1f).semantics { role = Role.Button },
          shapes = ButtonGroupDefaults.connectedLeadingButtonShapes(),
        ) {
          when (downloadState) {
            Download.STATE_COMPLETED -> {
              Icon(
                painter = painterResource(R.drawable.offline),
                contentDescription = stringResource(R.string.saved),
                modifier = Modifier.size(20.dp)
              )
            }
            Download.STATE_DOWNLOADING -> {
              CircularProgressIndicator(
                strokeWidth = 2.dp,
                modifier = Modifier.size(16.dp),
                color = MaterialTheme.colorScheme.onSurface
              )
            }
            else -> {
              Icon(
                painter = painterResource(R.drawable.download),
                contentDescription = stringResource(R.string.action_download),
                modifier = Modifier.size(20.dp)
              )
            }
          }
          Spacer(Modifier.size(ToggleButtonDefaults.IconSpacing))
          Text(
            text =
              when (downloadState) {
                Download.STATE_COMPLETED -> stringResource(R.string.saved)
                Download.STATE_DOWNLOADING -> stringResource(R.string.saving)
                else -> stringResource(R.string.save_album)
              },
            style = MaterialTheme.typography.labelMedium
          )
        }

        ToggleButton(
          checked = false,
          onCheckedChange = {
            if (songs.isNotEmpty()) {
              playerConnection.playQueue(
                YouTubePlaylistQueue(
                  playlistId = playlist.id,
                  playlistTitle = playlist.title,
                  initialSongs = songs.shuffled(),
                  initialContinuation = continuation
                )
              )
            }
          },
          modifier = Modifier.weight(1f).semantics { role = Role.Button },
          shapes = ButtonGroupDefaults.connectedMiddleButtonShapes(),
        ) {
          Icon(
            painter = painterResource(R.drawable.shuffle),
            contentDescription = stringResource(R.string.shuffle_content_desc),
            modifier = Modifier.size(20.dp)
          )
          Spacer(Modifier.size(ToggleButtonDefaults.IconSpacing))
          Text(
            stringResource(R.string.shuffle_label),
            style = MaterialTheme.typography.labelMedium,
            maxLines = 1,
            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
          )
        }

        ToggleButton(
          checked = false,
          onCheckedChange = {
            menuState.show {
              YouTubePlaylistMenu(
                playlist = playlist,
                songs = songs,
                coroutineScope = coroutineScope,
                onDismiss = menuState::dismiss,
              )
            }
          },
          modifier = Modifier.weight(1f).semantics { role = Role.Button },
          shapes = ButtonGroupDefaults.connectedTrailingButtonShapes(),
        ) {
          Icon(
            painter = painterResource(R.drawable.more_vert),
            contentDescription = stringResource(R.string.more_options),
            modifier = Modifier.size(20.dp)
          )
          Spacer(Modifier.size(ToggleButtonDefaults.IconSpacing))
          Text(stringResource(R.string.more_label), style = MaterialTheme.typography.labelMedium)
        }
      }
    }
  }
}

/** Items from the end of the list at which the next playlist page is loaded. */
private const val LOAD_MORE_THRESHOLD = 15
