package echo.music.iad1tya.ui.screens.settings

import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuAnchorType
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarScrollBehavior
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import androidx.navigation.NavController
import com.music.innertube.models.IpVersion
import echo.music.iad1tya.LocalPlayerAwareWindowInsets
import echo.music.iad1tya.R
import echo.music.iad1tya.constants.AlbumCanvasEnabledKey
import echo.music.iad1tya.constants.AppLanguageKey
import echo.music.iad1tya.constants.RecommendationSourceKey
import echo.music.iad1tya.constants.RecommendationSource
import echo.music.iad1tya.constants.SpotifySpDcKey
import kotlinx.coroutines.launch
import echo.music.iad1tya.constants.ContentCountryKey
import echo.music.iad1tya.constants.ContentLanguageKey
import echo.music.iad1tya.constants.CountryCodeToName
import echo.music.iad1tya.constants.EnableBetterLyricsKey
import echo.music.iad1tya.constants.EnableCronetKey
import echo.music.iad1tya.constants.EnableKugouKey
import echo.music.iad1tya.constants.EnableLrcLibKey
import echo.music.iad1tya.constants.EnablePaxsenixKey
import echo.music.iad1tya.constants.EnableSimpMusicKey
import echo.music.iad1tya.constants.EnableYouLyPlusKey
import echo.music.iad1tya.constants.FetchFasterLyricsKey
import echo.music.iad1tya.constants.ForceOpusKey
import echo.music.iad1tya.constants.HideExplicitKey
import echo.music.iad1tya.constants.HideVideoSongsKey
import echo.music.iad1tya.constants.HideYoutubeShortsKey
import echo.music.iad1tya.constants.IpVersionKey
import echo.music.iad1tya.constants.LanguageCodeToName
import echo.music.iad1tya.constants.LyricsProviderOrderKey
import echo.music.iad1tya.constants.LyricsRomanizeBelarusianKey
import echo.music.iad1tya.constants.LyricsRomanizeBulgarianKey
import echo.music.iad1tya.constants.LyricsRomanizeChineseKey
import echo.music.iad1tya.constants.LyricsRomanizeHindiKey
import echo.music.iad1tya.constants.LyricsRomanizeJapaneseKey
import echo.music.iad1tya.constants.LyricsRomanizeKoreanKey
import echo.music.iad1tya.constants.LyricsRomanizeKyrgyzKey
import echo.music.iad1tya.constants.LyricsRomanizeMacedonianKey
import echo.music.iad1tya.constants.LyricsRomanizePunjabiKey
import echo.music.iad1tya.constants.LyricsRomanizeRussianKey
import echo.music.iad1tya.constants.LyricsRomanizeSerbianKey
import echo.music.iad1tya.constants.LyricsRomanizeUkrainianKey
import echo.music.iad1tya.constants.ProxyEnabledKey
import echo.music.iad1tya.constants.ProxyPasswordKey
import echo.music.iad1tya.constants.ProxyTypeKey
import echo.music.iad1tya.constants.ProxyUrlKey
import echo.music.iad1tya.constants.ProxyUsernameKey
import echo.music.iad1tya.constants.QuickPicks
import echo.music.iad1tya.constants.QuickPicksKey
import echo.music.iad1tya.constants.RandomizeHomeOrderKey
import echo.music.iad1tya.constants.SYSTEM_DEFAULT
import echo.music.iad1tya.constants.ShowArtistBackgroundVideoKey
import echo.music.iad1tya.constants.ShowArtistDescriptionKey
import echo.music.iad1tya.constants.ShowArtistSubscriberCountKey
import echo.music.iad1tya.constants.ShowArtistVideoKey
import echo.music.iad1tya.constants.ShowMonthlyListenersKey
import echo.music.iad1tya.constants.ShowSpeedDialKey
import echo.music.iad1tya.constants.SponsorBlockEnabledKey
import echo.music.iad1tya.constants.SuggestionRegionKey
import echo.music.iad1tya.constants.SuggestionRegionSlugToName
import echo.music.iad1tya.constants.TopSize
import echo.music.iad1tya.lyrics.LyricsProviderRegistry
import echo.music.iad1tya.ui.component.DraggableLyricsProviderItem
import echo.music.iad1tya.ui.component.DraggableLyricsProviderList
import echo.music.iad1tya.ui.component.EnumDialog
import echo.music.iad1tya.ui.component.IconButton
import echo.music.iad1tya.ui.component.Material3SettingsGroup
import echo.music.iad1tya.ui.component.Material3SettingsItem
import echo.music.iad1tya.ui.component.PlaybackLogsDialog
import echo.music.iad1tya.ui.screens.search.suggestions.SuggestionRegionSheet
import echo.music.iad1tya.ui.utils.backToMain
import echo.music.iad1tya.utils.PlaybackLogManager
import echo.music.iad1tya.utils.rememberEnumPreference
import echo.music.iad1tya.utils.rememberPreference
import java.net.Proxy
import racra.compose.smooth_corner_rect_library.AbsoluteSmoothCornerShape

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContentSettings(
  navController: NavController,
  scrollBehavior: TopAppBarScrollBehavior,
  highlightKey: String? = null
) {
  val scrollState = androidx.compose.foundation.rememberScrollState()

  val context = LocalContext.current
  val scope = rememberCoroutineScope()


  val (spotifySpDc) = rememberPreference(key = SpotifySpDcKey, defaultValue = "")
  val (recommendationSource, onRecommendationSourceChange) = rememberEnumPreference(key = RecommendationSourceKey, defaultValue = RecommendationSource.YOUTUBE)
  
  LaunchedEffect(spotifySpDc, recommendationSource) {
      if (spotifySpDc.isBlank() && recommendationSource == RecommendationSource.SPOTIFY) {
          onRecommendationSourceChange(RecommendationSource.YOUTUBE)
      }
  }

  val (appLanguage, onAppLanguageChange) =
    rememberPreference(key = AppLanguageKey, defaultValue = SYSTEM_DEFAULT)

  val (lyricsRomanizeJapanese, onLyricsRomanizeJapaneseChange) =
    rememberPreference(LyricsRomanizeJapaneseKey, defaultValue = true)
  val (lyricsRomanizeKorean, onLyricsRomanizeKoreanChange) =
    rememberPreference(LyricsRomanizeKoreanKey, defaultValue = true)
  val (lyricsRomanizeChinese, onLyricsRomanizeChineseChange) =
    rememberPreference(LyricsRomanizeChineseKey, defaultValue = true)
  val (lyricsRomanizeHindi, onLyricsRomanizeHindiChange) =
    rememberPreference(LyricsRomanizeHindiKey, defaultValue = true)
  val (lyricsRomanizePunjabi, onLyricsRomanizePunjabiChange) =
    rememberPreference(LyricsRomanizePunjabiKey, defaultValue = true)
  val (lyricsRomanizeRussian, onLyricsRomanizeRussianChange) =
    rememberPreference(LyricsRomanizeRussianKey, defaultValue = true)
  val (lyricsRomanizeUkrainian, onLyricsRomanizeUkrainianChange) =
    rememberPreference(LyricsRomanizeUkrainianKey, defaultValue = true)
  val (lyricsRomanizeSerbian, onLyricsRomanizeSerbianChange) =
    rememberPreference(LyricsRomanizeSerbianKey, defaultValue = true)
  val (lyricsRomanizeBulgarian, onLyricsRomanizeBulgarianChange) =
    rememberPreference(LyricsRomanizeBulgarianKey, defaultValue = true)
  val (lyricsRomanizeBelarusian, onLyricsRomanizeBelarusianChange) =
    rememberPreference(LyricsRomanizeBelarusianKey, defaultValue = true)
  val (lyricsRomanizeKyrgyz, onLyricsRomanizeKyrgyzChange) =
    rememberPreference(LyricsRomanizeKyrgyzKey, defaultValue = true)
  val (lyricsRomanizeMacedonian, onLyricsRomanizeMacedonianChange) =
    rememberPreference(LyricsRomanizeMacedonianKey, defaultValue = true)

  val (contentLanguage, onContentLanguageChange) =
    rememberPreference(key = ContentLanguageKey, defaultValue = "system")
  val (contentCountry, onContentCountryChange) =
    rememberPreference(key = ContentCountryKey, defaultValue = "system")
  val (suggestionRegion, onSuggestionRegionChange) =
    rememberPreference(key = SuggestionRegionKey, defaultValue = "system")
  val (forceOpus, onForceOpusChange) = rememberPreference(key = ForceOpusKey, defaultValue = true)
  val (enableCronet, onEnableCronetChange) =
    rememberPreference(key = EnableCronetKey, defaultValue = true)
  val (hideExplicit, onHideExplicitChange) =
    rememberPreference(key = HideExplicitKey, defaultValue = false)
  val (hideVideoSongs, onHideVideoSongsChange) =
    rememberPreference(key = HideVideoSongsKey, defaultValue = false)

  val (hideYoutubeShorts, onHideYoutubeShortsChange) =
    rememberPreference(key = HideYoutubeShortsKey, defaultValue = false)
  val (sponsorBlockEnabled, onSponsorBlockEnabledChange) =
    rememberPreference(key = SponsorBlockEnabledKey, defaultValue = false)
  val (showArtistDescription, onShowArtistDescriptionChange) =
    rememberPreference(key = ShowArtistDescriptionKey, defaultValue = true)
  val (showArtistSubscriberCount, onShowArtistSubscriberCountChange) =
    rememberPreference(key = ShowArtistSubscriberCountKey, defaultValue = true)
  val (showMonthlyListeners, onShowMonthlyListenersChange) =
    rememberPreference(key = ShowMonthlyListenersKey, defaultValue = true)
  val (showArtistVideo, onShowArtistVideoChange) =
    rememberPreference(key = ShowArtistVideoKey, defaultValue = true)
  val (showArtistBackgroundVideo, onShowArtistBackgroundVideoChange) =
    rememberPreference(key = ShowArtistBackgroundVideoKey, defaultValue = true)
  val (proxyEnabled, onProxyEnabledChange) =
    rememberPreference(key = ProxyEnabledKey, defaultValue = false)
  val (proxyType, onProxyTypeChange) =
    rememberEnumPreference(key = ProxyTypeKey, defaultValue = Proxy.Type.HTTP)
  val (proxyUrl, onProxyUrlChange) =
    rememberPreference(key = ProxyUrlKey, defaultValue = "host:port")
  val (proxyUsername, onProxyUsernameChange) =
    rememberPreference(key = ProxyUsernameKey, defaultValue = "username")
  val (proxyPassword, onProxyPasswordChange) =
    rememberPreference(key = ProxyPasswordKey, defaultValue = "password")
  val (enableKugou, onEnableKugouChange) =
    rememberPreference(key = EnableKugouKey, defaultValue = true)
  val (enableLrclib, onEnableLrclibChange) =
    rememberPreference(key = EnableLrcLibKey, defaultValue = true)
  val (enableBetterLyrics, onEnableBetterLyricsChange) =
    rememberPreference(key = EnableBetterLyricsKey, defaultValue = true)
  val (enableSimpMusic, onEnableSimpMusicChange) =
    rememberPreference(key = EnableSimpMusicKey, defaultValue = true)
  val (enableYouLyPlus, onEnableYouLyPlusChange) =
    rememberPreference(key = EnableYouLyPlusKey, defaultValue = true)
  val (enablePaxsenix, onEnablePaxsenixChange) =
    rememberPreference(key = EnablePaxsenixKey, defaultValue = true)
  val (fetchFasterLyrics, onFetchFasterLyricsChange) =
    rememberPreference(key = FetchFasterLyricsKey, defaultValue = false)

  val (lyricsProviderOrder, onLyricsProviderOrderChange) =
    rememberPreference(
      key = LyricsProviderOrderKey,
      defaultValue = "",
    )
  val (lengthTop, onLengthTopChange) = rememberPreference(key = TopSize, defaultValue = "50")
  val (quickPicks, onQuickPicksChange) =
    rememberEnumPreference(key = QuickPicksKey, defaultValue = QuickPicks.QUICK_PICKS)
  val (showSpeedDial, onShowSpeedDialChange) =
    rememberPreference(key = ShowSpeedDialKey, defaultValue = true)
  val (randomizeHomeOrder, onRandomizeHomeOrderChange) =
    rememberPreference(RandomizeHomeOrderKey, defaultValue = false)
  val (ipVersion, onIpVersionChange) =
    rememberEnumPreference(IpVersionKey, defaultValue = IpVersion.AUTO)
  val (albumCanvasEnabled, onAlbumCanvasEnabledChange) =
    rememberPreference(key = AlbumCanvasEnabledKey, defaultValue = false)

  var showPlaybackLogsDialog by rememberSaveable { mutableStateOf(false) }
  var showSuggestionSheet by rememberSaveable { mutableStateOf(false) }
  val playbackLogs by PlaybackLogManager.logs.collectAsState()

  var showProxyConfigurationDialog by rememberSaveable { mutableStateOf(false) }

  if (showProxyConfigurationDialog) {
    var expandedDropdown by remember { mutableStateOf(false) }

    var tempProxyUrl by rememberSaveable { mutableStateOf(proxyUrl) }
    var tempProxyUsername by rememberSaveable { mutableStateOf(proxyUsername) }
    var tempProxyPassword by rememberSaveable { mutableStateOf(proxyPassword) }
    var authEnabled by rememberSaveable {
      mutableStateOf(proxyUsername.isNotBlank() || proxyPassword.isNotBlank())
    }

    AlertDialog(
      onDismissRequest = { showProxyConfigurationDialog = false },
      title = { Text(stringResource(R.string.config_proxy)) },
      text = {
        val dialogScrollState = androidx.compose.foundation.rememberScrollState()
        Column(
          modifier = Modifier.fillMaxWidth().verticalScroll(dialogScrollState),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          ExposedDropdownMenuBox(
            expanded = expandedDropdown,
            onExpandedChange = { expandedDropdown = !expandedDropdown },
            modifier = Modifier.fillMaxWidth()
          ) {
            OutlinedTextField(
              value = proxyType.name,
              onValueChange = {},
              readOnly = true,
              label = { Text(stringResource(R.string.proxy_type)) },
              trailingIcon = {
                ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedDropdown)
              },
              colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
              modifier =
                Modifier.menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable).fillMaxWidth()
            )
            ExposedDropdownMenu(
              expanded = expandedDropdown,
              onDismissRequest = { expandedDropdown = false }
            ) {
              listOf(Proxy.Type.HTTP, Proxy.Type.SOCKS).forEach { type ->
                DropdownMenuItem(
                  text = { Text(type.name) },
                  onClick = {
                    onProxyTypeChange(type)
                    expandedDropdown = false
                  }
                )
              }
            }
          }

          OutlinedTextField(
            value = tempProxyUrl,
            onValueChange = { tempProxyUrl = it },
            label = { Text(stringResource(R.string.proxy_url)) },
            modifier = Modifier.fillMaxWidth()
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(stringResource(R.string.enable_authentication))
            Switch(
              checked = authEnabled,
              onCheckedChange = {
                authEnabled = it
                if (!it) {
                  tempProxyUsername = ""
                  tempProxyPassword = ""
                }
              }
            )
          }

          AnimatedVisibility(visible = authEnabled) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              OutlinedTextField(
                value = tempProxyUsername,
                onValueChange = { tempProxyUsername = it },
                label = { Text(stringResource(R.string.proxy_username)) },
                modifier = Modifier.fillMaxWidth()
              )
              OutlinedTextField(
                value = tempProxyPassword,
                onValueChange = { tempProxyPassword = it },
                label = { Text(stringResource(R.string.proxy_password)) },
                modifier = Modifier.fillMaxWidth()
              )
            }
          }
        }
      },
      confirmButton = {
        TextButton(
          onClick = {
            onProxyUrlChange(tempProxyUrl)
            onProxyUsernameChange(if (authEnabled) tempProxyUsername else "")
            onProxyPasswordChange(if (authEnabled) tempProxyPassword else "")
            showProxyConfigurationDialog = false
          }
        ) {
          Text(stringResource(R.string.save))
        }
      },
      dismissButton = {
        TextButton(onClick = { showProxyConfigurationDialog = false }) {
          Text(stringResource(R.string.cancel))
        }
      }
    )
  }

  var showContentLanguageDialog by rememberSaveable { mutableStateOf(false) }

  if (showContentLanguageDialog) {
    EnumDialog(
      onDismiss = { showContentLanguageDialog = false },
      onSelect = {
        onContentLanguageChange(it)
        showContentLanguageDialog = false
      },
      title = stringResource(R.string.content_language),
      current = contentLanguage,
      values = (listOf(SYSTEM_DEFAULT) + LanguageCodeToName.keys.toList()),
      valueText = { LanguageCodeToName.getOrElse(it) { stringResource(R.string.system_default) } }
    )
  }

  var showContentCountryDialog by rememberSaveable { mutableStateOf(false) }

  if (showContentCountryDialog) {
    EnumDialog(
      onDismiss = { showContentCountryDialog = false },
      onSelect = {
        onContentCountryChange(it)
        showContentCountryDialog = false
      },
      title = stringResource(R.string.content_country),
      current = contentCountry,
      values = (listOf(SYSTEM_DEFAULT) + CountryCodeToName.keys.toList()),
      valueText = { CountryCodeToName.getOrElse(it) { stringResource(R.string.system_default) } }
    )
  }

  var showAppLanguageDialog by rememberSaveable { mutableStateOf(false) }

  if (showAppLanguageDialog) {
    EnumDialog(
      onDismiss = { showAppLanguageDialog = false },
      onSelect = {
        onAppLanguageChange(it)
        showAppLanguageDialog = false
      },
      title = stringResource(R.string.app_language),
      current = appLanguage,
      values = (listOf(SYSTEM_DEFAULT) + LanguageCodeToName.keys.toList()),
      valueText = { LanguageCodeToName.getOrElse(it) { stringResource(R.string.system_default) } }
    )
  }

  var showProviderPriorityDialog by rememberSaveable { mutableStateOf(false) }

  if (showProviderPriorityDialog) {
    val defaultOrder = LyricsProviderRegistry.getDefaultProviderOrder()

    val userToggleable =
      setOf("YouLyPlus", "Paxsenix", "BetterLyrics", "SimpMusic", "LrcLib", "Kugou")
    val enabledProviders =
      setOfNotNull(
        "LrcLib".takeIf { enableLrclib },
        "Kugou".takeIf { enableKugou },
        "BetterLyrics".takeIf { enableBetterLyrics },
        "SimpMusic".takeIf { enableSimpMusic },
        "YouLyPlus".takeIf { enableYouLyPlus },
        "Paxsenix".takeIf { enablePaxsenix },
      )

    val savedOrder = LyricsProviderRegistry.deserializeProviderOrder(lyricsProviderOrder)
    val normalizedOrder = savedOrder + defaultOrder.filter { it !in savedOrder }

    val lyricsIcon = painterResource(R.drawable.lyrics)
    val draggableItems = remember { mutableStateListOf<DraggableLyricsProviderItem>() }

    LaunchedEffect(normalizedOrder, enabledProviders) {
      val orderedEnabled = normalizedOrder.filter { it in enabledProviders }
      draggableItems.clear()
      draggableItems.addAll(
        orderedEnabled.map { name ->
          DraggableLyricsProviderItem(
            id = name,
            name = LyricsProviderRegistry.getDisplayName(name),
            icon = lyricsIcon,
          )
        }
      )
    }

    val cardShape = AbsoluteSmoothCornerShape(30.dp, 60)
    val blockShape = AbsoluteSmoothCornerShape(22.dp, 60)
    val actionShape = AbsoluteSmoothCornerShape(18.dp, 60)

    BasicAlertDialog(onDismissRequest = { showProviderPriorityDialog = false }) {
      Surface(
        modifier = Modifier.padding(horizontal = 24.dp).widthIn(max = 360.dp),
        shape = cardShape,
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        tonalElevation = 8.dp,
      ) {
        Column(
          modifier = Modifier.padding(horizontal = 18.dp, vertical = 18.dp),
          verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
          Surface(
            shape = blockShape,
            color = MaterialTheme.colorScheme.surfaceContainer,
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 14.dp),
              verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Surface(
                  shape = AbsoluteSmoothCornerShape(12.dp, 60),
                  color = MaterialTheme.colorScheme.secondaryContainer,
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                  ) {
                    Icon(
                      painter = painterResource(R.drawable.lyrics),
                      contentDescription = null,
                      tint = MaterialTheme.colorScheme.onSecondaryContainer,
                      modifier = Modifier.size(16.dp),
                    )
                    Text(
                      text = stringResource(R.string.lyrics_provider_priority),
                      style = MaterialTheme.typography.labelMedium,
                      fontWeight = FontWeight.SemiBold,
                      color = MaterialTheme.colorScheme.onSecondaryContainer,
                    )
                  }
                }
              }

              Text(
                text = stringResource(R.string.lyrics_provider_priority_desc),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }

          Surface(
            shape = blockShape,
            color = MaterialTheme.colorScheme.surfaceContainerLow,
            modifier = Modifier.fillMaxWidth().height(300.dp),
          ) {
            DraggableLyricsProviderList(
              items = draggableItems,
              onItemsReordered = { reordered ->
                val enabledOrder = reordered.map { it.id }

                val rest = normalizedOrder.filter { it !in enabledProviders }
                onLyricsProviderOrderChange(
                  LyricsProviderRegistry.serializeProviderOrder(enabledOrder + rest)
                )
              },
              modifier = Modifier.fillMaxWidth().padding(12.dp),
            )
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.End,
          ) {
            Button(
              onClick = { showProviderPriorityDialog = false },
              shape = actionShape,
            ) {
              Text(text = stringResource(R.string.close))
            }
          }
        }
      }
    }
  }

  var showQuickPicksDialog by rememberSaveable { mutableStateOf(false) }

  if (showQuickPicksDialog) {
    EnumDialog(
      onDismiss = { showQuickPicksDialog = false },
      onSelect = {
        onQuickPicksChange(it)
        showQuickPicksDialog = false
      },
      title = stringResource(R.string.set_quick_picks),
      current = quickPicks,
      values = QuickPicks.values().toList(),
      valueText = {
        when (it) {
          QuickPicks.QUICK_PICKS -> stringResource(R.string.quick_picks)
          QuickPicks.LAST_LISTEN -> stringResource(R.string.last_song_listened)
        }
      }
    )
  }

  var showTopLengthDialog by rememberSaveable { mutableStateOf(false) }

  if (showTopLengthDialog) {
    var tempLength by rememberSaveable { mutableFloatStateOf(lengthTop.toFloat()) }

    AlertDialog(
      onDismissRequest = { showTopLengthDialog = false },
      title = { Text(stringResource(R.string.top_length)) },
      text = {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Text(tempLength.toInt().toString())
          Slider(
            value = tempLength,
            onValueChange = { tempLength = it },
            valueRange = 1f..100f,
            steps = 98
          )
        }
      },
      confirmButton = {
        TextButton(
          onClick = {
            onLengthTopChange(tempLength.toInt().toString())
            showTopLengthDialog = false
          }
        ) {
          Text(stringResource(R.string.save))
        }
      }
    )
  }

  var showIpVersionDialog by rememberSaveable { mutableStateOf(false) }

  if (showIpVersionDialog) {
    EnumDialog(
      onDismiss = { showIpVersionDialog = false },
      onSelect = {
        onIpVersionChange(it)
        showIpVersionDialog = false
      },
      title = stringResource(R.string.network_ip_version),
      current = ipVersion,
      values = IpVersion.entries,
      valueText = {
        when (it) {
          IpVersion.AUTO -> stringResource(R.string.ip_version_auto)
          IpVersion.IPV4 -> stringResource(R.string.ip_version_ipv4)
          IpVersion.IPV6 -> stringResource(R.string.ip_version_ipv6)
        }
      }
    )
  }

  if (showPlaybackLogsDialog) {
    PlaybackLogsDialog(
      logs = playbackLogs,
      onClear = { PlaybackLogManager.clearLogs() },
      onDismiss = { showPlaybackLogsDialog = false }
    )
  }

  if (showSuggestionSheet) {
    SuggestionRegionSheet(
      currentRegionSlug = suggestionRegion,
      onRegionSelected = { onSuggestionRegionChange(it) },
      onDismiss = { showSuggestionSheet = false }
    )
  }

  Column(
    Modifier.windowInsetsPadding(
        LocalPlayerAwareWindowInsets.current.only(WindowInsetsSides.Horizontal)
      )
      .verticalScroll(scrollState)
      .padding(horizontal = 16.dp),
  ) {
    Spacer(
      Modifier.windowInsetsPadding(LocalPlayerAwareWindowInsets.current.only(WindowInsetsSides.Top))
    )

    Spacer(modifier = Modifier.height(16.dp))

    Material3SettingsGroup(
      scrollState = scrollState,
      title = "Privacy",
      items =
        listOf(
          Material3SettingsItem(
            isHighlighted = (highlightKey == "Blocked Artists"),
            title = { Text("Blocked Artists") },
            description = { Text("Manage hidden artists") },
            customIcon = { Icon(Icons.Default.Block, null) },
            onClick = { navController.navigate("blocked_artists") }
          )
        )
    )

    Material3SettingsGroup(
      scrollState = scrollState,
      title = stringResource(R.string.general),
      items =
        listOf(
          Material3SettingsItem(
            isHighlighted = (highlightKey == "Force Opus Audio"),
            icon = painterResource(R.drawable.music_note),
            title = { Text("Force Opus Audio (itag 251)") },
            description = {
              Text(
                "Force WebM/Opus streaming. Halves data usage and buffers 2x faster, but may lower raw bitrate."
              )
            },
            trailingContent = {
              Switch(
                checked = forceOpus,
                onCheckedChange = onForceOpusChange,
                thumbContent = {
                  Icon(
                    painter =
                      painterResource(id = if (forceOpus) R.drawable.check else R.drawable.close),
                    contentDescription = null,
                    modifier = Modifier.size(SwitchDefaults.IconSize),
                  )
                },
              )
            },
            onClick = { onForceOpusChange(!forceOpus) }
          ),
          Material3SettingsItem(
            isHighlighted = (highlightKey == "Enable HTTP/3 (Cronet)"),
            icon = painterResource(R.drawable.speed),
            title = { Text("Enable HTTP/3 (Cronet)") },
            description = {
              Text("Use QUIC over UDP for zero-latency streaming (Restart required)")
            },
            trailingContent = {
              Switch(
                checked = enableCronet,
                onCheckedChange = onEnableCronetChange,
                thumbContent = {
                  Icon(
                    painter =
                      painterResource(
                        id = if (enableCronet) R.drawable.check else R.drawable.close
                      ),
                    contentDescription = null,
                    modifier = Modifier.size(SwitchDefaults.IconSize),
                  )
                },
              )
            },
            onClick = { onEnableCronetChange(!enableCronet) }
          ),
          Material3SettingsItem(
            isHighlighted = (highlightKey == stringResource(R.string.content_language)),
            icon = painterResource(R.drawable.language),
            title = { Text(stringResource(R.string.content_language)) },
            description = {
              Text(
                LanguageCodeToName.getOrElse(contentLanguage) {
                  stringResource(R.string.system_default)
                }
              )
            },
            onClick = { showContentLanguageDialog = true }
          ),
          Material3SettingsItem(
            isHighlighted = (highlightKey == stringResource(R.string.content_country)),
            icon = painterResource(R.drawable.location_on),
            title = { Text(stringResource(R.string.content_country)) },
            description = {
              Text(
                CountryCodeToName.getOrElse(contentCountry) {
                  stringResource(R.string.system_default)
                }
              )
            },
            onClick = { showContentCountryDialog = true }
          ),
          Material3SettingsItem(
            isHighlighted = (highlightKey == "Suggestions Region"),
            icon = painterResource(R.drawable.globe_location_pin),
            title = { Text("Suggestions Region") },
            description = {
              Text(SuggestionRegionSlugToName.getOrElse(suggestionRegion) { "Global Charts" })
            },
            onClick = { showSuggestionSheet = true }
          ),
          Material3SettingsItem(
            isHighlighted = (highlightKey == stringResource(R.string.hide_explicit)),
            icon = painterResource(R.drawable.explicit),
            title = { Text(stringResource(R.string.hide_explicit)) },
            description = { Text(stringResource(R.string.hide_explicit_desc)) },
            trailingContent = {
              Switch(
                checked = hideExplicit,
                onCheckedChange = onHideExplicitChange,
                thumbContent = {
                  Icon(
                    painter =
                      painterResource(
                        id = if (hideExplicit) R.drawable.check else R.drawable.close
                      ),
                    contentDescription = null,
                    modifier = Modifier.size(SwitchDefaults.IconSize)
                  )
                }
              )
            },
            onClick = { onHideExplicitChange(!hideExplicit) }
          ),
          Material3SettingsItem(
            isHighlighted = (highlightKey == stringResource(R.string.hide_video_songs)),
            icon = painterResource(R.drawable.slow_motion_video),
            title = { Text(stringResource(R.string.hide_video_songs)) },
            description = { Text(stringResource(R.string.hide_video_songs_desc)) },
            trailingContent = {
              Switch(
                checked = hideVideoSongs,
                onCheckedChange = onHideVideoSongsChange,
                thumbContent = {
                  Icon(
                    painter =
                      painterResource(
                        id = if (hideVideoSongs) R.drawable.check else R.drawable.close
                      ),
                    contentDescription = null,
                    modifier = Modifier.size(SwitchDefaults.IconSize)
                  )
                }
              )
            },
            onClick = { onHideVideoSongsChange(!hideVideoSongs) }
          ),
          Material3SettingsItem(
            isHighlighted = (highlightKey == stringResource(R.string.hide_youtube_shorts)),
            icon = painterResource(R.drawable.hide_image),
            title = { Text(stringResource(R.string.hide_youtube_shorts)) },
            description = { Text(stringResource(R.string.hide_youtube_shorts_desc)) },
            trailingContent = {
              Switch(
                checked = hideYoutubeShorts,
                onCheckedChange = onHideYoutubeShortsChange,
                thumbContent = {
                  Icon(
                    painter =
                      painterResource(
                        id = if (hideYoutubeShorts) R.drawable.check else R.drawable.close
                      ),
                    contentDescription = null,
                    modifier = Modifier.size(SwitchDefaults.IconSize)
                  )
                }
              )
            },
            onClick = { onHideYoutubeShortsChange(!hideYoutubeShorts) }
          ),
          Material3SettingsItem(
            isHighlighted = (highlightKey == stringResource(R.string.content_sponsor_block)),
            icon = painterResource(R.drawable.skip_next),
            title = { Text(stringResource(R.string.content_sponsor_block)) },
            description = { Text(stringResource(R.string.content_sponsor_block_desc)) },
            trailingContent = {
              Switch(
                checked = sponsorBlockEnabled,
                onCheckedChange = onSponsorBlockEnabledChange,
                thumbContent = {
                  Icon(
                    painter =
                      painterResource(
                        id = if (sponsorBlockEnabled) R.drawable.check else R.drawable.close
                      ),
                    contentDescription = null,
                    modifier = Modifier.size(SwitchDefaults.IconSize)
                  )
                }
              )
            },
            onClick = { onSponsorBlockEnabledChange(!sponsorBlockEnabled) }
          )
        )
    )

    Spacer(modifier = Modifier.height(16.dp))

    Material3SettingsGroup(
      scrollState = scrollState,
      title = stringResource(R.string.album_text),
      items =
        listOf(
          Material3SettingsItem(
            isHighlighted = (highlightKey == stringResource(R.string.show_album_canvas)),
            icon = painterResource(R.drawable.slow_motion_video),
            title = { Text(stringResource(R.string.show_album_canvas)) },
            description = { Text(stringResource(R.string.show_album_canvas_desc)) },
            trailingContent = {
              Switch(
                checked = albumCanvasEnabled,
                onCheckedChange = onAlbumCanvasEnabledChange,
                thumbContent = {
                  Icon(
                    painter =
                      painterResource(
                        id = if (albumCanvasEnabled) R.drawable.check else R.drawable.close
                      ),
                    contentDescription = null,
                    modifier = Modifier.size(SwitchDefaults.IconSize)
                  )
                }
              )
            },
            onClick = { onAlbumCanvasEnabledChange(!albumCanvasEnabled) }
          )
        )
    )

    Spacer(modifier = Modifier.height(16.dp))

    Material3SettingsGroup(
      scrollState = scrollState,
      title = stringResource(R.string.app_language),
      items =
        listOf(
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Material3SettingsItem(
              isHighlighted = (highlightKey == stringResource(R.string.app_language)),
              icon = painterResource(R.drawable.language),
              title = { Text(stringResource(R.string.app_language)) },
              description = { Text(stringResource(R.string.app_language_desc)) },
              onClick = {
                context.startActivity(
                  Intent(
                    Settings.ACTION_APP_LOCALE_SETTINGS,
                    "package:${context.packageName}".toUri()
                  )
                )
              }
            )
          } else {
            Material3SettingsItem(
              isHighlighted = (highlightKey == stringResource(R.string.app_language)),
              icon = painterResource(R.drawable.language),
              title = { Text(stringResource(R.string.app_language)) },
              description = {
                Text(
                  LanguageCodeToName.getOrElse(appLanguage) {
                    stringResource(R.string.system_default)
                  }
                )
              },
              onClick = { showAppLanguageDialog = true }
            )
          }
        )
    )

    Spacer(modifier = Modifier.height(16.dp))

    Material3SettingsGroup(
      scrollState = scrollState,
      title = stringResource(R.string.proxy),
      items =
        buildList {
          add(
            Material3SettingsItem(
              isHighlighted = (highlightKey == stringResource(R.string.network_ip_version)),
              icon = painterResource(R.drawable.network_node),
              title = { Text(stringResource(R.string.network_ip_version)) },
              description = {
                Text(
                  when (ipVersion) {
                    IpVersion.AUTO -> stringResource(R.string.ip_version_auto)
                    IpVersion.IPV4 -> stringResource(R.string.ip_version_ipv4)
                    IpVersion.IPV6 -> stringResource(R.string.ip_version_ipv6)
                  }
                )
              },
              onClick = { showIpVersionDialog = true }
            )
          )
          add(
            Material3SettingsItem(
              isHighlighted = (highlightKey == stringResource(R.string.enable_proxy)),
              icon = painterResource(R.drawable.wifi_proxy),
              title = { Text(stringResource(R.string.enable_proxy)) },
              description = { Text(stringResource(R.string.enable_proxy_desc)) },
              trailingContent = {
                Switch(
                  checked = proxyEnabled,
                  onCheckedChange = onProxyEnabledChange,
                  thumbContent = {
                    Icon(
                      painter =
                        painterResource(
                          id = if (proxyEnabled) R.drawable.check else R.drawable.close
                        ),
                      contentDescription = null,
                      modifier = Modifier.size(SwitchDefaults.IconSize)
                    )
                  }
                )
              },
              onClick = { onProxyEnabledChange(!proxyEnabled) }
            )
          )
          if (proxyEnabled) {
            add(
              Material3SettingsItem(
                isHighlighted = (highlightKey == stringResource(R.string.config_proxy)),
                icon = painterResource(R.drawable.settings),
                title = { Text(stringResource(R.string.config_proxy)) },
                description = { Text(stringResource(R.string.config_proxy_desc)) },
                onClick = { showProxyConfigurationDialog = true }
              )
            )
          }
        }
    )

    Spacer(modifier = Modifier.height(16.dp))

    Material3SettingsGroup(
      scrollState = scrollState,
      title = stringResource(R.string.lyrics),
      items =
        listOf(
          Material3SettingsItem(
            isHighlighted = (highlightKey == stringResource(R.string.lyrics_romanization)),
            icon = painterResource(R.drawable.language_korean_latin),
            title = { Text(stringResource(R.string.lyrics_romanization)) },
            description = { Text(stringResource(R.string.lyrics_romanization_desc)) },
            trailingContent = {
              Switch(
                checked =
                  lyricsRomanizeJapanese &&
                    lyricsRomanizeKorean &&
                    lyricsRomanizeChinese &&
                    lyricsRomanizeRussian,
                onCheckedChange = { checked ->
                  onLyricsRomanizeJapaneseChange(checked)
                  onLyricsRomanizeKoreanChange(checked)
                  onLyricsRomanizeChineseChange(checked)
                  onLyricsRomanizeHindiChange(checked)
                  onLyricsRomanizePunjabiChange(checked)
                  onLyricsRomanizeRussianChange(checked)
                  onLyricsRomanizeUkrainianChange(checked)
                  onLyricsRomanizeSerbianChange(checked)
                  onLyricsRomanizeBulgarianChange(checked)
                  onLyricsRomanizeBelarusianChange(checked)
                  onLyricsRomanizeKyrgyzChange(checked)
                  onLyricsRomanizeMacedonianChange(checked)
                },
                thumbContent = {
                  Icon(
                    painter =
                      painterResource(
                        id =
                          if (lyricsRomanizeJapanese && lyricsRomanizeKorean) R.drawable.check
                          else R.drawable.close
                      ),
                    contentDescription = null,
                    modifier = Modifier.size(SwitchDefaults.IconSize)
                  )
                }
              )
            },
            onClick = {
              val checked =
                !(lyricsRomanizeJapanese &&
                  lyricsRomanizeKorean &&
                  lyricsRomanizeChinese &&
                  lyricsRomanizeRussian)
              onLyricsRomanizeJapaneseChange(checked)
              onLyricsRomanizeKoreanChange(checked)
              onLyricsRomanizeChineseChange(checked)
              onLyricsRomanizeHindiChange(checked)
              onLyricsRomanizePunjabiChange(checked)
              onLyricsRomanizeRussianChange(checked)
              onLyricsRomanizeUkrainianChange(checked)
              onLyricsRomanizeSerbianChange(checked)
              onLyricsRomanizeBulgarianChange(checked)
              onLyricsRomanizeBelarusianChange(checked)
              onLyricsRomanizeKyrgyzChange(checked)
              onLyricsRomanizeMacedonianChange(checked)
            }
          )
        )
    )

    Spacer(modifier = Modifier.height(16.dp))

    Material3SettingsGroup(
      scrollState = scrollState,
      title = stringResource(R.string.misc),
      items =
        listOf(
          Material3SettingsItem(
            isHighlighted = (highlightKey == stringResource(R.string.recommendation_source)),
            icon = painterResource(R.drawable.explore_outlined),
            title = { Text(stringResource(R.string.recommendation_source)) },
            description = {
              Text(
                when (recommendationSource) {
                  RecommendationSource.YOUTUBE -> stringResource(R.string.recommendation_source_youtube)
                  RecommendationSource.SPOTIFY -> stringResource(R.string.recommendation_source_spotify)
                }
              )
            },
            onClick = {
              if (recommendationSource == RecommendationSource.YOUTUBE) {
                if (spotifySpDc.isBlank()) {
                   // Cannot switch to Spotify if not logged in
                   scope.launch {
                       android.widget.Toast.makeText(context, R.string.spotify_recommendation_login_required, android.widget.Toast.LENGTH_LONG).show()
                   }
                } else {
                   onRecommendationSourceChange(RecommendationSource.SPOTIFY)
                }
              } else {
                onRecommendationSourceChange(RecommendationSource.YOUTUBE)
              }
            }
          ),
          Material3SettingsItem(
            isHighlighted = (highlightKey == stringResource(R.string.randomize_home_order)),
            icon = painterResource(R.drawable.shuffle),
            title = { Text(stringResource(R.string.randomize_home_order)) },
            description = { Text(stringResource(R.string.randomize_home_order_desc)) },
            trailingContent = {
              Switch(
                checked = randomizeHomeOrder,
                onCheckedChange = onRandomizeHomeOrderChange,
                thumbContent = {
                  Icon(
                    painter =
                      painterResource(
                        id = if (randomizeHomeOrder) R.drawable.check else R.drawable.close
                      ),
                    contentDescription = null,
                    modifier = Modifier.size(SwitchDefaults.IconSize)
                  )
                }
              )
            },
            onClick = { onRandomizeHomeOrderChange(!randomizeHomeOrder) }
          ),
          Material3SettingsItem(
            isHighlighted = (highlightKey == stringResource(R.string.top_length)),
            icon = painterResource(R.drawable.trending_up),
            title = { Text(stringResource(R.string.top_length)) },
            description = { Text(lengthTop) },
            onClick = { showTopLengthDialog = true }
          ),
          Material3SettingsItem(
            isHighlighted = (highlightKey == stringResource(R.string.set_quick_picks)),
            icon = painterResource(R.drawable.home_outlined),
            title = { Text(stringResource(R.string.set_quick_picks)) },
            description = {
              Text(
                when (quickPicks) {
                  QuickPicks.QUICK_PICKS -> stringResource(R.string.quick_picks)
                  QuickPicks.LAST_LISTEN -> stringResource(R.string.last_song_listened)
                }
              )
            },
            onClick = { showQuickPicksDialog = true }
          ),
          Material3SettingsItem(
            isHighlighted = (highlightKey == "Speed Dial"),
            icon = painterResource(R.drawable.grid_view),
            title = { Text("Speed Dial") },
            description = { Text("Show Speed Dial on the Home Screen") },
            trailingContent = {
              Switch(
                checked = showSpeedDial,
                onCheckedChange = { onShowSpeedDialChange(it) },
                colors =
                  SwitchDefaults.colors(
                    checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                    checkedTrackColor = MaterialTheme.colorScheme.primary
                  )
              )
            },
            onClick = { onShowSpeedDialChange(!showSpeedDial) }
          )
        )
    )

    Spacer(modifier = Modifier.height(16.dp))

    Spacer(
      Modifier.windowInsetsPadding(
        LocalPlayerAwareWindowInsets.current.only(WindowInsetsSides.Bottom)
      )
    )
  }

  TopAppBar(
    title = { Text(stringResource(R.string.content)) },
    navigationIcon = {
      IconButton(
        onClick = navController::navigateUp,
        onLongClick = navController::backToMain,
      ) {
        Icon(
          painterResource(R.drawable.arrow_back),
          contentDescription = null,
        )
      }
    }
  )
}
