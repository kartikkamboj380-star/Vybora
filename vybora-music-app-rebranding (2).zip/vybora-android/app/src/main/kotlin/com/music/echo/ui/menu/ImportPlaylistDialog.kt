package echo.music.iad1tya.ui.menu

import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.TextFieldValue
import echo.music.iad1tya.LocalDatabase
import echo.music.iad1tya.R
import echo.music.iad1tya.db.entities.PlaylistEntity
import echo.music.iad1tya.ui.component.TextFieldDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

@Composable
fun ImportPlaylistDialog(
  isVisible: Boolean,
  onGetSong: suspend () -> List<String>,
  playlistTitle: String,
  onDismiss: () -> Unit,
) {
  val database = LocalDatabase.current
  val coroutineScope = rememberCoroutineScope()

  val textFieldValue by remember { mutableStateOf(TextFieldValue(text = playlistTitle)) }
  var songIds by remember { mutableStateOf<List<String>?>(null) }

  if (isVisible) {
    TextFieldDialog(
      icon = { Icon(painter = painterResource(R.drawable.add), contentDescription = null) },
      title = { Text(text = stringResource(R.string.import_playlist)) },
      initialTextFieldValue = textFieldValue,
      autoFocus = false,
      onDismiss = onDismiss,
      onDone = { finalName ->
        val newPlaylist = PlaylistEntity(name = finalName)
        database.query { insert(newPlaylist) }

        coroutineScope.launch(Dispatchers.IO) {
          val playlist = database.playlist(newPlaylist.id).firstOrNull()

          if (playlist != null) {
            songIds = onGetSong()
            database.addSongToPlaylist(playlist, songIds!!)
          }

          onDismiss()
        }
      }
    )
  }
}
